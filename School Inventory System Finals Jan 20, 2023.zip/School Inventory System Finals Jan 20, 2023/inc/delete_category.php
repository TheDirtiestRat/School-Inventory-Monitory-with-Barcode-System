<?php
require "connect_db.php";
require 'session.php';

$cat_id = $_POST['CatId'];

$sql = "DELETE FROM `Category` WHERE categoryId = $cat_id;";

if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-danger" role="alert">
            Selected Category is Deleted
        </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Deleted Category! Category is listed in an item
        </div>';
}

?>