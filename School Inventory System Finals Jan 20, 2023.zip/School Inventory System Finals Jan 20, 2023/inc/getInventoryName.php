<?php

require "connect_db.php";
require 'session.php';

$q = $_REQUEST['q'];

$sql = "SELECT inventoryName FROM `Inventory` WHERE inventoryId = $q;";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

if (mysqli_num_rows($result) > 0) { 
    echo $row['inventoryName']; 
} else { 
    echo "Inventory name"; 
}

?>