<?php
require "connect_db.php";
require 'session.php';

$inv_id = $_POST['InvId'];

$sql = "DELETE FROM `Inventory` WHERE `Inventory`.`inventoryId` = $inv_id";

if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-success" role="alert">
            Selected Inventory is Deleted
            </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Deleted Inventory! Inventory is being used
        </div>';
}

?>