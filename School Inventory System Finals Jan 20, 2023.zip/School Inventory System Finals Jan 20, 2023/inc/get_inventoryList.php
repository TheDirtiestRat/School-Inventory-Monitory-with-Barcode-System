<?php
require "connect_db.php";
require 'session.php';

$u_id = $_SESSION['userId'];

if ($u_id == 1){
    $sql = "SELECT inventoryId, inventoryName FROM `Inventory`";
}else {
    $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id;";
}

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_array($result)) {
        $id = $row['inventoryId'];
        $inv_n = $row['inventoryName'];

        echo '<li class="list-group-item border-0 bg-transparent">';
        echo '<a class="text-secondary text-decoration-none sidebar-list" href="#collapse' . $id . '" data-bs-toggle="collapse" aria-expanded="false" aria-controls="collapse' . $id . '" id="ct' . $id . '" onclick="loadInventoryDetails(event,' . "'" . $inv_n . "'" . ',' . $id . ')">';
        echo '<p class="m-0"><strong>' . $inv_n .'</strong></p>';
        echo '</a>';
        echo '</li>';


        $sql2 = "SELECT categoryId, categoryName, inventoryId FROM `Category` WHERE inventoryId = $id;";
        $res = mysqli_query($conn, $sql2);


        if (mysqli_num_rows($res) > 0) {
            echo '<div class="collapse" id="collapse' . $id . '">';
            echo '<ul>';
            while ($row = mysqli_fetch_array($res)) {
                if ($id == $row['inventoryId']) {
                    echo '<li class="mb-2">';
                    echo '<a href="#" class="text-secondary text-decoration-none category" id="list' . $id . '" onclick="getItemListByCategory(' . $row['categoryId'] . ',' . $id . ')">';
                    echo  $row['categoryName'];
                    echo '</a>';
                    echo '</li>';
                }
            }

            echo "</ul>";
            
            echo '<ul>';
            // echo '<li class="mb-2"><a href="#" class="text-secondary text-decoration-none" data-bs-toggle="modal" data-bs-target="#deleteInventoryModal" onclick="onDelInv(' . "'" . $inv_n . "'" . ')"> Delete Inventory </a>';
            // echo '<a href="#" class="text-secondary text-decoration-none" data-bs-toggle="modal" data-bs-target="#editInventoryModal" onclick="getCatAndStatList('. "'" . $inv_n . "'" .')"> Edit Inventory </a></li>';
            echo "</ul>";
            echo '<hr class="text-secondary">';
            echo "</div>";
        } else {
            echo '<div class="collapse" id="collapse' . $id . '">';
            echo '<ul>';
            echo '<li class=" mb-2">';
            echo '<p class="text-secondary"> No Categories added yet </p>';
            echo '</li>';
            // echo '<li class="mb-2"><a href="#" class="text-secondary text-decoration-none" data-bs-toggle="modal" data-bs-target="#deleteInventoryModal" onclick="onDelInv('. "'" . $inv_n . "'" .')"> Delete Inventory </a>';
            // echo '<a href="#" class="text-secondary text-decoration-none" data-bs-toggle="modal" data-bs-target="#editInventoryModal" onclick="getCatAndStatList('. "'" . $inv_n . "'" .')"> Edit Inventory </a></li>';
            echo "</ul>";
            echo '<hr class="text-secondary">';
            echo '</div>';
        }
    }
} else {
    echo '<p class=" text-secondary text-center lead">No Inventories</p>';
}
