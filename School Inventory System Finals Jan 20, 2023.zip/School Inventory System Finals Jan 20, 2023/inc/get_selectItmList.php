<?php
require "connect_db.php";
require 'session.php';

$id = $_POST['ItmInv'];

$sql = "SELECT itemId, itemName FROM `Item` WHERE inventoryId = $id AND Item.IsArchive != 1";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        echo '<li class="list-group-item" onclick="getItemId(event, '. $row['itemId'] .')">'.
        $row['itemName']
        .'</li>';
    }
}else{
    echo '<li class="list-group-item text-secondary">
    No Items
    </li>';
}

?>