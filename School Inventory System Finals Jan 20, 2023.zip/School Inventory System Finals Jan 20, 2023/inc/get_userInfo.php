<?php
require "connect_db.php";
require 'session.php';

$sql = "SELECT `userName`, `userPass`, `userFirstName`, `userLastName`, `userEmail`, `userContact`, `userAddress`, `userOccupation`, `userPictureFile` FROM `User` WHERE userName = " . "'" . $user . "'" . ";";
$result = mysqli_query($conn, $sql);

$uname;
$fname;
$lname;
$email;
$contact;
$address;
$userOccupation;
$picFileName;

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $uname = $row['userName'];
        $fname = $row['userFirstName'];
        $lname = $row['userLastName'];
        $email = $row['userEmail'];
        $contact = $row['userContact'];
        $address = $row['userAddress'];
        $userOccupation = $row['userOccupation'];
        $picFileName = $row['userPictureFile'];
    }
}

$userImg = "";

if ($picFileName == "userImg.png") {
    $userImg = "../assets/userImg.png";
} else {
    $userImg = "../files/uploads/".$picFileName;
}

echo '<div class=" col-md-4 p-md-3">
<div class="row">
    <div class=" text-center mb-md-3">
        <img src="'. $userImg .'" class="img-thumbnail rounded-circle" width="200px" height="200px" alt="...">
        <h1>'. $uname .'</h1>
        <p class="text-secondary">'. $userOccupation .'</p>
        <button type="button" class="btn btn-dark" id="uploadProPic" data-bs-toggle="modal" data-bs-target="#updUserPic">Update profile pic</button>
    </div>
</div>
</div>
<div class=" col-md-8 p-md-3">
<h1>Profile Details</h1>

<hr>

<div class="row">
    <div class=" col-md-4">
        <p>First name</p>
    </div>
    <div class="col">
        <p id="firstname">'. $fname .'</p>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <p>Last name</p>
    </div>
    <div class="col">
        <p id="lastname">'. $lname .'</p>
    </div>
</div>

<hr>

<!-- <h4>About</h4> -->

<div class="row">
    <div class=" col-md-4">
        <p>Email</p>
    </div>
    <div class="col">
        <p id="email">'.$email .'</p>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <p>Contact</p>
    </div>
    <div class="col">
        <p id="contacts">'. $contact .'</p>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <p>Address</p>
    </div>
    <div class="col">
        <p id="address">'. $address .'</p>
    </div>
</div>


<button type="button" class="btn btn-dark float-md-end" id="edtBtn" data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit User details</button>
</div>';
