<?php
// include "session.php";
$user = $_SESSION['userName'];

$sql = "SELECT `userName`, `userPictureFile` FROM `User` WHERE userName = " . "'" . $user . "'" . ";";
$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

$u_name = $row['userName'];
$u_pic = $row['userPictureFile'];

$userImg = "";

if ($u_pic == "userImg.png") {
    $userImg = "../assets/userImg.png";
} else {
    $userImg = "../files/uploads/".$u_pic;
}

echo '<nav class="navbar navbar-expand-lg bg-light border-bottom fixed-top">
<div class="container-fluid">


    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <img src="../assets/bars-solid.svg" alt="" class="icon">
    </button>

    <div class="collapse navbar-collapse " id="navbarNav">
        <ul class="navbar-nav dropdown  d-flex align-items-center">
            <li class="nav-item" >
                <a class="nav-link" id="dashboard" href="dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" id="file maintenance" href="fileMaintenance.php">File Maintenance</a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" id="transactions" href="transactions.php">
                    Transactions
                </a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" id="reports" href="reports.php">
                    Reports
                </a>
            </li>

            <!-- <li class="nav-item" >
                <a class="nav-link" id="barcodes" href="barcodes.php">
                    Barcodes
                </a>
            </li> -->
        </ul>
    </div>

    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav dropdown">
            <li class="nav-item text-center">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="pe-2">';
                    echo ucfirst($user);
                    echo '</span> <img src="'. $userImg .'" alt="" class="profile-pic">
                </a>



                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>';

                    if (ucfirst($user) == "Admin"){
                        echo '<li><a class="dropdown-item" href="add_newUser.php">Add new users</a></li>';
                    }
                    
                    echo '<li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="logout.php">
                            Log-out
                        </a></li>
                </ul>
            </li>
        </ul>
    </div>


    <div class="justify-content-end">
        <ul class="m-0 list-unstyled">

        </ul>
    </div>
</div>
</nav>

<script>
var page_title = document.title;

if (page_title == "Dashboard") {
    document.getElementById("dashboard").classList.add("active");
}
if (page_title == "File Maintenance") {
    document.getElementById("file maintenance").classList.add("active");
}
if (page_title == "Transactions") {
    document.getElementById("transactions").classList.add("active");
}
if (page_title == "Reports") {
    document.getElementById("reports").classList.add("active");
}
if (page_title == "Barcodes") {
    document.getElementById("barcodes").classList.add("active");
}
</script>';

?>