<?php
require "connect_db.php";
require 'session.php';

$stat_id = $_POST['StatId'];

$sql = "DELETE FROM `Status` WHERE statusId = $stat_id;";

if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-danger" role="alert">
            Selected Status is Deleted
        </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Deleted Status! Status is listed in an item
        </div>';
}

?>