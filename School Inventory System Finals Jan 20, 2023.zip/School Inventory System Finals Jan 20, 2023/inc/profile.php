<?php

require "connect_db.php";
require 'session.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <!--Nav Bar-->
    <?php include "navbar.php"; ?>

    <!-- gets the user info details -->
    <?php

    $sql = "SELECT `userName`, `userPass`, `userFirstName`, `userLastName`, `userEmail`, `userContact`, `userAddress`, `userOccupation`, `userPictureFile` FROM `User` WHERE userName = " . "'" . $user . "'" . ";";
    $result = mysqli_query($conn, $sql);

    $uname;
    $fname;
    $lname;
    $password;
    $email;
    $contact;
    $address;
    $userOccupation;
    $picFileName;

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $uname = $row['userName'];
            $fname = $row['userFirstName'];
            $lname = $row['userLastName'];
            $email = $row['userEmail'];
            $password = $row['userPass'];
            $contact = $row['userContact'];
            $address = $row['userAddress'];
            $userOccupation = $row['userOccupation'];
            $picFileName = $row['userPictureFile'];
        }
    }

    $userImg = "";

    if ($picFileName == "userImg.png") {
        $userImg = "../assets/userImg.png";
    } else {
        $userImg = "../files/uploads/" . $picFileName;
    }

    ?>

    <section class="nb-padding">

        <div class=" container-md p-md-4">
            <div class=" row border border-radius" id="displayUserInfo">

                <div class=" col-md-4 p-md-3">
                    <div class="row">
                        <div class=" text-center mb-md-3">
                            <img src=<?php echo $userImg ?> class="img-thumbnail rounded-circle" alt="..." id="profImg">
                            <h1><?php echo $uname ?></h1>
                            <p class="text-secondary"><?php echo $userOccupation ?></p>
                            <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#updUserPic">Update profile pic</button>
                        </div>
                    </div>
                </div>
                <div class=" col-md-8 p-md-3">
                    <h1>Profile Details</h1>

                    <hr>

                    <div class="row">
                        <div class=" col-md-4">
                            <p>First name</p>
                        </div>
                        <div class="col">
                            <p id="firstname"><?php echo $fname ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <p>Last name</p>
                        </div>
                        <div class="col">
                            <p id="lastname"><?php echo $lname ?></p>
                        </div>
                    </div>

                    <hr>

                    <!-- <h4>About</h4> -->

                    <div class="row">
                        <div class=" col-md-4">
                            <p>Email</p>
                        </div>
                        <div class="col">
                            <p id="email"><?php echo $email ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <p>Contact</p>
                        </div>
                        <div class="col">
                            <p id="contacts"><?php echo $contact ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <p>Address</p>
                        </div>
                        <div class="col">
                            <p id="address"><?php echo $address ?></p>
                        </div>
                    </div>


                    <button type="button" class="btn btn-dark float-md-end" id="edtBtn" data-bs-toggle="modal" data-bs-target="#editProfileModal">Update User details</button>
                </div>

            </div>
            <div class=" p-md-3 text-md-center">
                <?php if (isset($_GET['alert'])) { ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $_GET['alert']; ?>
                    </div>
                <?php } ?>

                <?php if (isset($_GET['error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $_GET['error']; ?>
                    </div>
                <?php } ?>
            </div>
        </div>

    </section>

    <!-- Modals -->
    <!-- update profile details modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Profile</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- inputs -->
                    <form class="row g-3 mb-3" action="edit_userInfo.php" method="POST" id="editProfForm">
                        <div class="col-md-4">
                            <label for="inputEmail4" class="form-label">First Name</label>
                            <input type="text" class="form-control" name="Fname" id="inpFname" placeholder="First name" maxlength="16" value=<?php echo '"' . $fname . '"' ?>>
                        </div>
                        <div class="col-md-4">
                            <label for="inputEmail4" class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="Lname" id="inpLname" placeholder="Last name" maxlength="16" value=<?php echo '"' . $lname . '"' ?>>
                        </div>
                        <div class="col-md-4">
                            <label for="inputEmail4" class="form-label">User Name</label>
                            <input type="text" class="form-control" name="Uname" id="inpUname" placeholder="User name" maxlength="16" value=<?php echo '"' . $uname . '"' ?>>
                        </div>

                        <div class="col-md-6">
                            <label for="inputEmail4" class="form-label">Email</label>
                            <input type="email" class="form-control" name="Email" id="inpEmail" placeholder="email@email.com" maxlength="32" value=<?php echo '"' . $email . '"' ?>>
                        </div>

                        <div class="col-md-6">
                            <label for="inputPassword4" class="form-label">New Password</label>
                            <input type="password" class="form-control" name="Newpass" id="inpNewPass" placeholder="password" maxlength="24" value=<?php echo '"' . $password . '"' ?>>
                        </div>
                        <div class="col-md-6">
                            <label for="inputEmail4" class="form-label">Contact Number</label>
                            <input type="number" class="form-control" name="Contact" id="inpContact" placeholder="Contact number" maxlength="11" value=<?php echo '"' . $contact . '"' ?>>
                        </div>
                        <div class="col-md-6">
                            <label for="inpOccupation" class="form-label">Occupation</label>
                            <input type="text" class="form-control" name="userOccupation" id="inpOccupation" pattern="^[A-Za-z \s*]+$" placeholder="User" maxlength="32" value=<?php echo '"' . $userOccupation . '"' ?>>
                        </div>
                        <div class="col-12">
                            <label for="inputAddress" class="form-label">Address</label>
                            <input type="text" class="form-control" name="Address" id="inputAddress" placeholder="143 Main St" maxlength="64" value=<?php echo '"' . $address . '"' ?>>
                        </div>
                    </form>

                    <!-- <div id="updAlrtWrn">
                    </div> -->
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" onclick="updateUserInfo()">
                        Update Profile
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- update user picture modal -->
    <div class="modal fade" id="updUserPic" tabindex="-1" aria-labelledby="updUserPic" aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Update User Profile Picture</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class=" text-center mb-md-3" id="changeProfilePic">

                        <?php
                        $sql = "SELECT `userPictureFile` FROM `User` WHERE userName = " . "'" . $user . "'" . ";";
                        $result = mysqli_query($conn, $sql);
                        $row = mysqli_fetch_assoc($result);
                        $picfile = $row['userPictureFile'];
                        ?>

                        <a class="btn rounded-circle p-0" href="#" role="" id="uploadProPic"><img src=<?php echo $userImg ?> class="img-thumbnail rounded-circle" alt="..." id="profileImg"></a>
                        <p class="text-secondary">Change Profile picture</p>
                    </div>

                    <!-- form for updating profile picture -->
                    <form class=" d-none" action="update_userPicture.php" method="POST" enctype="multipart/form-data" id="editProfPic">
                        <input class="" type="file" name="file" id="file" accept="image/*">
                        <button type="submit" name="submit" id="subBtn">submit</button>
                    </form>
                </div>

                <div id="picAlrtWrn">

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" onclick="updateUserPicture()">Update picture</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Script functionality -->
    <script src="../js/custom js/changeProfilePic.js"></script>
    <script src="../js/custom js/responseOutputscript.js"></script>
    <script>
        // loads user information
        // loadUserInfo();

        // reset the modal after closing
        var editProfileModal = document.getElementById('editProfileModal');

        editProfileModal.addEventListener('hidden.bs.modal', function() {
            // document.getElementById("editProfForm").reset();
            img.setAttribute('src', "../assets/userImg.png");
        });

        var updUserPicModal = document.getElementById('updUserPic');

        updUserPicModal.addEventListener('hidden.bs.modal', function() {
            img.setAttribute('src', "../assets/userImg.png");
        });

        const inputfname = document.getElementById("inpFname")
        const inputlname = document.getElementById("inpLname")
        const inputUname = document.getElementById("inpUname")

        const inputEmail = document.getElementById("inpEmail")
        const inputNewPass = document.getElementById("inpNewPass")
        const inpuContact = document.getElementById("inpContact")
        const inputAddress = document.getElementById("inputAddress")

        function loadUserInfo() {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("displayUserInfo").innerHTML = this.responseText;
                }

            };

            xmlhttp.open("POST", "get_userInfo.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send();
        }


        function updateUserInfo() {
            document.getElementById("editProfForm").submit();
        }

        function updateUserPicture() {
            document.getElementById("subBtn").click();
        }
    </script>
</body>

</html>