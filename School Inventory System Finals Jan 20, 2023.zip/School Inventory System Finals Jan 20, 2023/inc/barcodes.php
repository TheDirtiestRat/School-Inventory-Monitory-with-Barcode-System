<?php

require "connect_db.php";
require_once 'session.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barcodes</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>

    <script src="../js/barcode/JsBarcode.all.min.js"></script>
    <script type="text/javascript" src="../js/jquery/jquery-3.6.1.min.js"></script>
    <script type="text/javascript" src="../js/printThis.js"></script>

    <script src="../js/saveImg/html2canvas.min.js"></script>

    <?php
    $u_id = $_SESSION['userId'];

    if ($u_id == 1){
        $sql = "SELECT inventoryId, inventoryName FROM `Inventory` LIMIT 1;";
    }else {
        $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id LIMIT 1;";
    }

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo '<script> window.onload = function() {loadBarcodes(';
        echo 'event';
        echo ",";
        echo "'";
        echo $row['inventoryName'];
        echo "'";
        echo ')';
        echo '};</script>';
    } else {
        echo '<script></script>';
    }
    ?>
</head>

<body>

    <!--Nav Bar-->
    <?php include "navbar.php"; ?>

    <!-- Sidebar section -->
    <section class="nb-padding sidebar position-fixed h-100" id="sidebar">

        <!-- <div class="p-3 sidebar bg-dark position-fixed overflow-scroll h-100 position-relative rounded-end" id="sidebar"> -->
        <div class="p-3 h-100 bg-dark overflow-scroll rounded-end">
            <div class="row m-0">
                <div class="col-10">
                    <h3 class="text-light">Inventory Barcodes</h3>
                </div>
                <div class="col-2"><button class="btn-close btn-close-white" onclick="sidebar_close()"></button></div>
            </div>

            <ul class="list-group list-group-flush bg-transparent" id="invBarcodeList">
                <!-- PHP code for generating list of inventory -->
                <?php
                if ($u_id == 1){
                    $sql = "SELECT inventoryId, inventoryName FROM `Inventory`";
                }else {
                    $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id;";
                }

                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_array($result)) {
                        $id = $row['inventoryId'];
                        $inv_n = $row['inventoryName'];

                        echo '<li class="list-group-item border-0 bg-transparent">';
                        echo '<a class="text-secondary text-decoration-none sidebar-list" id="sb-list" onclick="loadBarcodes(';
                        // echo "'";
                        // echo $inv_n;
                        // echo "'";
                        echo 'event';
                        echo ",";
                        // echo $id;
                        echo "'";
                        echo $inv_n;
                        echo "'";
                        echo ')">';
                        echo $inv_n;
                        echo '</a>';
                        echo '</li>';
                    }
                } else {
                    echo '<p class=" text-secondary text-center lead">No Inventories</p>';
                }
                ?>
            </ul>
        </div>
    </section>

    <!-- Content section -->
    <section class="nb-padding">

        <!-- Main -->
        <div class="cm-close" id="content_section">
            <div class="p-4 pb-0" id="headerStats">
                <div class="bg-white">
                    <button type="button" class="btn btn-light text-start" onclick="sidebar_open()">
                        <img src="../assets/bars-solid.svg" alt="" class="icon">
                    </button>
                    <div class="row">
                        <div class="col d-flex align-items-end">
                            <h1 class=" display-3 m-0">Barcodes</h1>
                        </div>
                        <div class="col d-flex align-items-end justify-content-end">
                            <p class="lead m-1">
                                <?php echo date("l jS \of F Y"); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <hr>
            </div>


            <div class="container-fluid p-4 pt-0" id="barcdContents">

                <?php
                if ($u_id == 1){
                    $sql = "SELECT inventoryId, inventoryName FROM `Inventory`";
                }else {
                    $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id;";
                }

                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_array($result)) {
                        $in_id = $row['inventoryId'];

                        echo '<div class="barcodesContent" id="' . $row['inventoryName'] . '" style="display: none">';
                        echo '<div class="row mb-3">';
                        echo '<div class="col"><h3 id="invName">' . $row['inventoryName'] . '</h3></div>';
                        echo '<div class="col-3 text-end">';
                        echo '<a id="prntBtn" onclick="downloadAllBarcodes(';
                        echo "'invBarcodes" . $row['inventoryId'] . "'";
                        echo ')" data-bs-toggle="tooltip" data-bs-title="download All Barcodes">
                        <img src="../assets/download-solid.svg" alt="" class="icon-md">
                        </a>
                        </div>
                        </div>';

                        echo '<div id="invBarcodes' . $row['inventoryId'] . '" class="row gap-3 p-2 justify-content-center">';


                        $sql2 = "SELECT Item.itemId, Item.itemName, Item.itemBarcode FROM `Item` WHERE Item.inventoryId = $in_id;";
                        $res = mysqli_query($conn, $sql2);

                        if (mysqli_num_rows($res) > 0) {
                            while ($row = mysqli_fetch_array($res)) {

                                echo '<div class="card" data-bs-toggle="tooltip" data-bs-title="download Barcode" id="bar' . $row['itemId'] . '" onclick="downloadBarcodeImg(' . "'" . "bar" . $row['itemId'] . "'" . ')" style="width: 16rem;" >
                                            <div class="card-body text-center">
                                                <svg id="barcode' . $row['itemId'] . '" class="barcode"></svg>
                                                <p class="card-title m-0">' . $row['itemName'] . ' ' . $row['itemId'] . '</p>
                                            </div>
                                        </div>';


                                echo '<script>
                                    JsBarcode("#barcode' . $row['itemId'] . '", "' . $row['itemBarcode'] . '", {
                                    format: "ITF",
                                    width: 1.5,
                                    height: 80,
                                    });
                                </script>';
                            }
                        } else {
                            echo '<h3 class=" text-secondary text-center">No Barcodes generated</h3>';
                        }


                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<h3 class=" text-secondary text-center">No Barcodes generated</h3>';
                }

                ?>
            </div>
        </div>
    </section>

    <!-- Script functionalities -->

    <script>
        // for initializing
        const invNameContent = document.getElementById('invName');
        const invBarContent = document.getElementById('itmBarcodeList');

        // for initializing the bootstrap tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))


        function loadBarcodes(evt, contentName) {
            // Declare all variables
            var i, tabcontent;

            // Get all elements with class="tabcontent" and hide them
            tabcontent = document.getElementsByClassName("barcodesContent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            document.getElementById(contentName).style.display = "block";
            // evt.currentTarget.className += " active";

            // Get all elements with class="tablinks" and remove the class "active"
            var item = document.getElementsByClassName("sidebar-list");
            for (i = 0; i < item.length; i++) {
                item[i].className = item[i].className.replace("text-light", "");
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            evt.currentTarget.className += " text-light";

        }

        // for printing barcodes in individual form and all
        function printBarcodes(elem_cls) {
            var printContents = document.getElementById(elem_cls).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        }

        function downloadAllBarcodes(element) {
            html2canvas(document.querySelector("#" + element)).then(canvas => {
                // document.body.appendChild(canvas);
                var img = canvas.toDataURL();
                downloadURI(img, element + ".png");

            });
        }

        function downloadBarcodeImg(element) {
            html2canvas(document.querySelector("#" + element)).then(canvas => {
                // document.body.appendChild(canvas);
                var img = canvas.toDataURL();
                downloadURI(img, element + ".png");

            });
        }

        function downloadURI(uri, name) {
            var link = document.createElement("a");

            link.download = name;
            link.href = uri;
            document.body.appendChild(link);
            link.click();
            link.remove();
            //after creating link you should delete dynamic link
            //clearDynamicLink(link); 
        }

        //creates a parameter to pass on the ajax so the php file can use
        function createParameterString(parameters) {
            // Create parameter string
            var parameterString = "";
            var isFirst = true;
            for (var index in parameters) {
                if (!isFirst) {
                    parameterString += "&";
                }
                parameterString += encodeURIComponent(index) + "=" + encodeURIComponent(parameters[index]);
                isFirst = false;
            }

            return parameterString;
        }


        // for the sidebar functionality
        var sidebar = document.getElementById("sidebar");
        var content = document.getElementById("content_section");

        function sidebar_open() {
            sidebar.classList.remove("close");
            sidebar.classList.add("open");

            content.classList.remove("cm-open");
            content.classList.add("cm-close");

        }

        function sidebar_close() {
            sidebar.classList.remove("open");
            sidebar.classList.add("close");

            content.classList.remove("cm-close");
            content.classList.add("cm-open");
        }
    </script>

</body>

</html>