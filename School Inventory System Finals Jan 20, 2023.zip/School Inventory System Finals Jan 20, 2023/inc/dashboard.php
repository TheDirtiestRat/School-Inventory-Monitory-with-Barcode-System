<?php

require "connect_db.php";
require_once 'session.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>

    <script src="../node_modules/chart.js/dist/chart.umd.js"></script>
</head>

<body>

    <!--Nav Bar-->
    <?php include "navbar.php"; ?>


    <!-- Content section -->
    <section class="nb-padding">
        <div class="p-4 pb-0" id="headerStats">

            <div class="bg-white">
                <div class="row">
                    <div class="col d-flex align-items-end">
                        <h1 class=" display-3 m-0"><?php echo ucfirst($user); ?> Dashboard</h1>
                    </div>
                    <div class="col d-flex align-items-end justify-content-end">
                        <p class="lead m-0">
                            <?php echo date("l jS \of F Y"); ?>
                        </p>
                    </div>
                </div>
                <hr>
            </div>

            <div class="container-fluid p-4 pt-2">

                <h1>Overview</h1>
                <hr>

                <div class="row mb-md-3 h-75">
                    <div class="col">
                        <div class="row mb-sm-3">
                            <div class="col-sm mb-3 mb-sm-0">
                                <div class="card text-center">
                                    <div class="card-header">
                                        Items Total
                                    </div>
                                    <?php
                                    $u_id = $_SESSION['userId'];

                                    if ($u_id == 1){
                                        $sql = "SELECT COUNT(Item.itemId) as total_items FROM `Inventory` 
                                        LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId";
                                    }else {
                                        $sql = "SELECT COUNT(Item.itemId) as total_items FROM `Inventory` 
                                        LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId 
                                        WHERE userId = $u_id";
                                    }
                                    

                                    $result = mysqli_query($conn, $sql);

                                    $row = mysqli_fetch_assoc($result);
                                    $total_itms = $row['total_items'];
                                    ?>
                                    <div class="card-body">
                                        <h1><?php echo $row['total_items']; ?></h1>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm mb-3 mb-sm-0">
                                <div class="card text-center ">
                                    <div class="card-header">
                                        On Stock
                                    </div>
                                    <?php
                                    if ($u_id == 1){
                                        $sql = "SELECT COUNT(`itemId`) AS remainingItems FROM `Item` WHERE `itemId` NOT IN (SELECT itemId FROM Transaction) AND `inventoryId` IN (SELECT inventoryId FROM Inventory);";
                                    }else {
                                        $sql = "SELECT COUNT(`itemId`) AS remainingItems FROM `Item` WHERE `itemId` NOT IN (SELECT itemId FROM Transaction) AND `inventoryId` IN (SELECT inventoryId FROM Inventory WHERE userId = $u_id);";
                                    }
                                    
                                    $result = mysqli_query($conn, $sql);

                                    $row = mysqli_fetch_assoc($result);
                                    ?>
                                    <div class="card-body">
                                        <h1><?php echo $row['remainingItems']; ?></h1>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm mb-3 mb-sm-0">
                            <div class="card h-100">
                                <div class="card-header">
                                    Items chart
                                </div>
                                <div class="card-body">
                                    <div>
                                        <canvas id="barChart" style="height: 200px;"></canvas>
                                    </div>
                                </div>
                                <div class="card-footer text-muted">
                                    Last update <?php echo date("d/m/Y"); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm mb-3 mb-sm-0">
                        <div class="card h-100">
                            <div class="card-header">
                                Inventory chart
                            </div>
                            <div class="card-body">
                                <div>
                                    <canvas id="pieChart"></canvas>
                                </div>
                            </div>
                            <div class="card-footer text-muted">
                                Last update <?php echo date("d/m/Y"); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                Transactions chart during this dates
                            </div>
                            <div class="card-body">
                                <div>
                                    <canvas id="lineChart" height="350px"></canvas>
                                </div>
                            </div>
                            <div class="card-footer text-muted">
                                Last update <?php echo date("d/M/Y"); ?>
                            </div>
                        </div>
                    </div>
                </div>

    </section>

    <?php
    //query for the transaction
    if ($u_id == 1) {
        $sql = "SELECT COUNT(transactionId) AS num_transactions, transactionDate  FROM `Transaction` GROUP BY transactionDate";
    }else {
        $sql = "SELECT COUNT(transactionId) AS num_transactions, transactionDate  FROM `Transaction` WHERE userId = $u_id GROUP BY transactionDate";
    }
    
    $result = mysqli_query($conn, $sql);

    $trns_date = array();
    $trns_values = array();

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            // $date = date_format($row['transactionDate'], "d/M/Y");
            
            array_push($trns_date, $row['transactionDate']);
            array_push($trns_values, $row['num_transactions']);
        }
    } 

    $trns_json = json_encode($trns_date);
    $trns_v_json = json_encode($trns_values);


    //query for number of items total borrow
    if ($u_id == 1) {
        $sql = "SELECT Item.itemName, COUNT(transactionId) AS total FROM `Transaction` LEFT JOIN Item ON Transaction.itemId = Item.itemId GROUP BY transactionName;";
    }else {
        $sql = "SELECT Item.itemName, COUNT(transactionId) AS total FROM `Transaction` INNER JOIN Item ON Transaction.itemId = Item.itemId WHERE userId = $u_id GROUP BY transactionName;";
    }
    
    $result = mysqli_query($conn, $sql);

    $itm_names = array();
    $itm_values = array();

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            array_push($itm_names, $row['itemName']);
            array_push($itm_values, $row['total']);
        }
    } 

    $itm_n_json = json_encode($itm_names);
    $itm_v_json = json_encode($itm_values);


    //query for the inventory of the items
    // $inv_n_json = json_encode($inv_names);
    // $inv_v_json = json_encode($inv_values);

    if ($u_id == 1) {
        $sql = "SELECT inventoryName, COUNT(Item.inventoryId) as total FROM `Inventory` LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId GROUP BY inventoryName;";
    }else {
        $sql = "SELECT inventoryName, COUNT(Item.inventoryId) as total FROM `Inventory` LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId WHERE userId = $u_id GROUP BY inventoryName;";
    }
    
    $result = mysqli_query($conn, $sql);

    $inv_names = array();
    $inv_values = array();

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            array_push($inv_names, $row['inventoryName']);
            array_push($inv_values, $row['total']);
        }
    } 
    // else {
    //     echo '<h3 class=" text-secondary">No Inventories added yet</h3>';
    // }

    $inv_n_json = json_encode($inv_names);
    $inv_v_json = json_encode($inv_values);
    ?>

    <!-- Script Functionality -->
    <script>
        const ctx = document.getElementById('lineChart');
        const brc = document.getElementById('barChart');
        const pie = document.getElementById('pieChart');



        var transacValuesX = <?php echo $trns_json ?>;
        var transacValuesY = <?php echo $trns_v_json ?>;

        var itemsX = <?php echo $itm_n_json ?>;
        var itemsValueY = <?php echo $itm_v_json ?>;

        var inventories = <?php echo $inv_n_json ?>;
        var inventoyrValues = <?php echo $inv_v_json ?>;


        var xValues = ["Mar", "Aprl", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];

        var barColors = ['rgba(255, 99, 132, 0.2)',
            'rgba(255, 159, 64, 0.2)',
            'rgba(255, 205, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(201, 203, 207, 0.2)'
        ];
        var boarderColors = ['rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
        ];

        new Chart(ctx, {
            type: "line",
            data: {
                labels: transacValuesX,
                datasets: [{
                    label: 'Transaction Items Date:',
                    data: transacValuesY,
                    backgroundColor: barColors,
                    borderColor: boarderColors,
                    fill: false,
                    tension: 0.1
                }]
            },
            options: {
                legend: {
                    display: false
                },
                maintainAspectRatio: false
            }
        });


        new Chart(brc, {
            type: 'bar',
            data: {
                labels: itemsX,
                datasets: [{
                    label: 'Item',
                    data: itemsValueY,
                    backgroundColor: barColors,
                    borderColor: boarderColors,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    },
                    x: {
                        ticks: {
                            display: false
                        }
                    }
                },
                maintainAspectRatio: false
            }
        });



        new Chart(pie, {
            type: "doughnut",
            data: {
                labels: inventories,
                datasets: [{
                    backgroundColor: barColors,
                    borderColor: boarderColors,
                    data: inventoyrValues
                }]
            },
            options: {
                title: {
                    display: true,
                    text: "World Wide Wine Production"
                },
                maintainAspectRatio: false

            }
        });
    </script>

</body>

</html>