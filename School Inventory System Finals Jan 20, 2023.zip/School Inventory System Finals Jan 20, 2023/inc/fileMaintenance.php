<?php

require "connect_db.php";
require_once 'session.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Maintenance</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>

    <script src="../js/barcode/JsBarcode.all.min.js"></script>
    <script type="text/javascript" src="../js/jquery/jquery-3.6.1.min.js"></script>

    <script type="text/javascript" src="../js/printThis.js"></script>
    <script src="../js/saveImg/html2canvas.min.js"></script>
    <script src="../js/custom js/responseOutputscript.js"></script>
    <?php
    $u_id = $_SESSION['userId'];
    $u_n = $_SESSION['userName'];

    $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId =" . $u_id . " LIMIT 1;";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo '<script> window.onload = function() {loadInventoryDetails(event,' . "'" . $row['inventoryName'] . "'" . ',' . "'" . $row['inventoryId'] . "'" . '); var inventoryId =' . $row['inventoryId'] . '; var itemId;};</script>';
    } else {
        echo '<script>var inventoryId = 0; var inventoryName = "";  var itemId;</script>';
    }
    ?>
</head>

<body>

    <!--Nav Bar-->
    <?php include "navbar.php"; ?>

    <!-- Sidebar section-->
    <section class="nb-padding sidebar position-fixed h-100" id="sidebar">
        <div class="p-3 h-100 bg-dark overflow-scroll rounded-end ">
            <div class="row m-0">
                <div class="col-10">
                    <h3 class="text-light">Inventory List</h3>
                </div>
                <div class="col-2"><button class="btn-close btn-close-white" onclick="sidebar_close()"></button></div>
            </div>


            <ul class="list-group list-group-flush bg-transparent mb-3" id="inventoryList">

                <!-- PHP code for generating list of inventory -->

            </ul>

            <?php
            if ($u_id == 1) {
                echo '<div class="w-100">
                <button type="button" class="btn btn-light w-100 d-flex align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#addInventoryModal" data-bs-toggle="tooltip" data-bs-title="add new inventory">
                    <img src="../assets/circle-plus-solid.svg" class="icon me-1" alt=""> New Inventory
                </button>
            </div>';
            }
            ?>

        </div>
    </section>

    <!-- Content section -->
    <section class="nb-padding h-100">

        <!-- Main -->
        <div class="cm-close" id="content_section" style="min-width: 900px;">
            <div class="p-4 pb-0" id="headerStats">
                <div class="bg-white">
                    <button type="button" class="btn btn-light text-start" onclick="sidebar_open()">
                        <img src="../assets/bars-solid.svg" alt="" class="icon">
                    </button>

                    <div class="row mb-2 h-auto">
                        <div class="col">
                            <h1 id="inventoryName">Inventory</h1>
                        </div>

                        <?php
                        if ($u_id == 1) {
                            echo '<div class="col h-auto w-100">
                            <button type="button" class="btn btn-dark m-1 float-end" data-bs-toggle="modal" data-bs-target="#addCategoryModal" onclick="">
                                + New Category
                            </button>
                            <button type="button" class="btn btn-dark m-1 float-end" data-bs-toggle="modal" data-bs-target="#addStatusModal" onclick="">
                                + New Status
                            </button>
                            <button type="button" class="btn btn-dark m-1 float-end" data-bs-toggle="modal" data-bs-target="#addItemModal" onclick="openAddItemModal()">
                                + Add Item
                            </button>

                            <button type="button" class="btn btn-danger m-1 float-end" data-bs-toggle="modal" data-bs-target="#deleteInventoryModal" onclick="onDelInv(inventoryName)">
                                Remove Inventory
                            </button>
                            <button type="button" class="btn btn-secondary m-1 float-end" data-bs-toggle="modal" data-bs-target="#editInventoryModal" onclick="getCatAndStatList(inventoryName)">
                                Edit Inventory
                            </button>
                        </div>';
                        }
                        ?>

                    </div>

                    <div class="row mb-3">
                        <div class="col-8">
                            <form class="d-flex" role="search">
                                <input id="searchBar" class="form-control me-2" type="search" placeholder="Search Item Name..." aria-label="Search" onkeyup="searchItem()">
                                <button class="btn btn-dark" type="submit" onclick="searchItem()">Search</button>
                            </form>
                        </div>
                        <div class="col">
                            <select class="form-select" aria-label="Default select example" id="slcSort">
                                <option selected>Sort By:</option>
                                <option value="itemDate">Date</option>
                                <option value="itemName">Item name</option>
                                <option value="itemId">ID</option>
                            </select>
                        </div>
                    </div>

                    <div class="row m-0">
                        <div id="liveAlertPlaceholder"></div>
                        <!-- <?php
                                // if (isset($_GET['alert'])) {
                                //     echo '<div class="col p-0">
                                //     <div class="alert alert-success alert-dismissible fade show" role="alert">
                                //         ' . $_GET['alert'] . ' 
                                //         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                //     </div>
                                // </div>';
                                // }
                                // if (isset($_GET['error'])) {
                                //     echo '<div class="col p-0">
                                //     <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                //         ' . $_GET['error'] . ' 
                                //         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                //     </div>
                                // </div>';
                                // }
                                ?> -->
                    </div>
                </div>
                <hr>
            </div>


            <div class="container-fluid p-4 pt-0" id="inventoryContents">
                <?php
                if ($u_id == 1) {
                    $sql = "SELECT inventoryId, inventoryName FROM `Inventory`";
                } else {
                    $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id;";
                }

                // $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id;";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_array($result)) {
                        $in_id = $row['inventoryId'];

                        echo '<div class="tableContent" id="' . $row['inventoryName'] . '" style="display: none">';
                        echo '<div class="p-2 ps-3 pe-3 border border-radius">
                        <div class="row" id="itmBarcodeList">';


                        $sql2 = "SELECT `itemId`, `itemName`, itemAmount, `itemBarcode`, Category.categoryName, Status.statusName, `itemDate` FROM `Item` 
                        INNER JOIN Category ON Item.categoryId = Category.categoryId 
                        INNER JOIN Status ON Item.statusId = Status.statusId WHERE Item.inventoryId = $in_id AND Item.IsArchive != 1;";
                        $res = mysqli_query($conn, $sql2);

                        if (mysqli_num_rows($res) > 0) {
                            echo '<div class="col">
                            <form action="" method="post" id="invItmForm" class="invform">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">
                                            <a href="" ata-bs-toggle="tooltip" data-bs-title="remove items" data-bs-toggle="modal" data-bs-target="#deleteItemModal" data-bs-toggle="tooltip" data-bs-title="delete selected items" id="deleteBtn" onclick="selectItemsToDelete()">
                                                <img src="../assets/trash-can-solid.svg" alt="" width="16px" class="">
                                            </a>
                                        </th>
                                        <th scope="col">#</th>
                                        <th scope="col">Item name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Category</th>
                                        <th></th>
                                        <th></th>
                                        <th scope="col">Barcode</th>
                                    </tr>
                                </thead>';

                            echo '<tbody class="table-group-divider" id="item_table' . $in_id . '">';
                            $index = 0;
                            while ($row = mysqli_fetch_array($res)) {
                                $index++;
                                echo '<tr>';
                                echo '<td class="align-middle">
                                        <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="' . $row['itemId'] . '" aria-label="...">
                                        </td>';
                                echo '<th class="align-middle">' . $index . '</th>';
                                echo '<td class="align-middle">' . $row['itemName'] . '</td>';
                                echo '<td class="align-middle">' . $row['itemAmount'] . '</td>';
                                echo '<td class="align-middle">' . $row['statusName'] . '</td>';
                                echo '<td class="align-middle">' . $row['categoryName'] . '</td>';

                                echo '<td class="align-middle">';
                                echo '<a href="#"  data-bs-toggle="collapse" data-bs-target="#colps' . $row['itemId'] . '" aria-expanded="false" aria-controls="collapseExample">';
                                echo '<img data-bs-toggle="tooltip" data-bs-title="show item history" src="../assets/caret-down-solid.svg" width="16px" alt="" class="">';
                                echo '</a>';
                                echo '</td>';

                                echo '<td class="align-middle"><a href="#" data-bs-toggle="tooltip" data-bs-title="download barcode" onclick="downloadBarcodeImg(' . "'" . $row['itemName'] . "'" . ', ' . $row['itemBarcode'] . ')">';
                                echo '<img src="../assets/download-solid.svg" width="16px" alt="" class="">';
                                echo '</a></td>';
                                echo '<td class="align-middle">' . $row['itemBarcode'] . '</td>';

                                echo '<td class="text-end">';
                                echo '<a href="#"  data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
                                echo '<img data-bs-toggle="tooltip" data-bs-title="edit item" src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
                                echo '</a>';
                                echo '</td>';
                                echo '</tr>';

                                echo '
                                <tr>
                                    <td colspan="10" class="collapse" id="colps' . $row['itemId'] . '">
                                        <div class="card card-body">
                                            <table class="table table-hover">
                                                <thead>
                                                    <th>Item</th>
                                                    <th>Inventory</th>
                                                    <th>Added</th>
                                                    <th>Modified</th>
                                                    <th></th>
                                                </thead>
                                                <tbody>';
                                $id = $row['itemId'];
                                $sql4 = "SELECT `historyId`, Item.itemName, Inventory.inventoryName, `dateAdded`, `dateModified`, `dateRemoved` FROM `ItemHistory` 
                                                LEFT JOIN Item ON ItemHistory.itemId = Item.itemId 
                                                LEFT JOIN Inventory ON ItemHistory.inventoryId = Inventory.inventoryId 
                                                WHERE ItemHistory.itemId = $id";

                                $res2 = mysqli_query($conn, $sql4);

                                if (mysqli_num_rows($res2) > 0) {
                                    while ($row = mysqli_fetch_array($res2)) {
                                        echo '<tr>
                                                                <td>' . $row['itemName'] . '</td>
                                                                <td>' . $row['inventoryName'] . '</td>
                                                                <td>' . $row['dateAdded'] . '</td>
                                                                <td>' . $row['dateModified'] . '</td>
                                                            </tr>';
                                    }
                                }
                                echo '</tbody>
                                            </table>
                                        </div>
                                    </td>
                                </tr>';
                            }
                            echo '</tbody>
                                        </table>
                                            </form>
                                            </div>';
                        } else {
                            echo '<h3 class=" text-secondary text-center">No Items added</h3>';
                        }

                        echo '</div></div>';
                        echo '</div>';
                        $index = 0;
                    }
                } else {
                    echo '<h3 class=" text-secondary text-center">No Inventory added</h3>';
                }

                ?>
            </div>

        </div>
    </section>


    <!-- Modals -->
    <!-- add Item modal -->
    <!-- <form action="add_item.php" method="post"> -->
    <div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light" id="addItemModalLabel">
                        Item to Add in the Inventory
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" id="addItmForm">
                        <div class="mb-1">
                            <label for="exampleFormControlInput1" class="form-label">Item name</label>
                            <input name="itemName" type="text" class="form-control" id="inputItmName" placeholder="input Item name" maxlength="32">
                        </div>
                        <div class="mb-1">
                            <label for="exampleFormControlInput1" class="form-label">Item Specification</label>
                            <input name="itemSpecify" type="text" class="form-control" id="inputItmSpecify" placeholder="input Item specification" maxlength="16">
                        </div>

                        <div class="mb-3">
                            <div class="col" id="slctInventory">
                                <label for="" class=" col-auto col-form-label">Inventory</label>
                                <select class="form-select" aria-label="Defaultselectexample" name="selectInv" id="selectInv">
                                    <?php
                                    $sql = "SELECT `inventoryId`, `inventoryName`, `userId` FROM `inventory` WHERE `userId` = $u_id";
                                    $result = mysqli_query($conn, $sql);

                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo '<option value="' . $row['inventoryId'] . '">' . $row['inventoryName'] . '</option>';
                                        }
                                    } else {
                                        echo '<option selected>No Inventory</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="row g-3" id="selectStat&Cat">
                                <div class="col" id="slctCategory">
                                    <label for="" class=" col-auto col-form-label">Category</label>
                                    <select class="form-select" aria-label="Defaultselectexample" name="selectCat" id="selectCat">

                                    </select>
                                </div>
                                <div class="col" id="slctStatus">
                                    <label for="" class=" col-auto col-form-label">Status</label>
                                    <select class="form-select" aria-label="Defaultselectexample" name="selectStat" id="selectStat">

                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="mb-2 row float-end">
                            <label for="inputAmount" class=" col-auto col-form-label">Quantity</label>
                            <div class="col-auto">
                                <input type="number" name="inputAmount" style="width: 6rem;" class="form-control" id="inputAmount" value="1">
                            </div>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" data-bs-dismiss="modal" onclick="addItem()">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- </form> -->
    <!-- delete item modal -->
    <div class="modal fade" id="deleteItemModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="deleteItemLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="deleteItemLabel">Remove Item in the Inventory</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-2" id="dltNotif">
                        Are you sure you want to Remove 00 item?
                    </div>

                    <!-- <div id="wrnAlrtDel">

                    </div> -->

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal" onclick="deleteItems()" id="yesDel">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <!-- edit Item modal -->
    <div class="modal fade" id="editItemModal" tabindex="-1" aria-labelledby="editItem" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light" id="editItem">
                        Edit Item in the Inventory
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" id="editItemForm">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Item name</label>
                            <input type="text" class="form-control" id="newItemNameInput" placeholder="new name of the Item" maxlength="32">
                        </div>

                        <div class="mb-3">
                            <div class="row g-3" id="editStat&Cat">
                                <div class="col" id="editCategory">
                                    <select class="form-select" aria-label="Defaultselectexample" name="selectCat" id="slctEditCat">

                                    </select>
                                </div>
                                <div class="col" id="editStatus">
                                    <select class="form-select" aria-label="Defaultselectexample" name="selectStat" id="slctEditStat">

                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>

                    <div id="editItmWrnAlrt">

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" data-bs-dismiss="modal" onclick="editItm()">
                        Edit Item
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- add Category modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="categoryModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light" id="categoryModal">
                        Add new category
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" id="catForm">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Category name</label>
                            <input name="categoryName" type="text" class="form-control" id="inputCatName" placeholder="input name of the Category" maxlength="24">
                        </div>
                    </form>

                    <div id="categoryWrnAlrt">

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" data-bs-dismiss="modal" onclick="addCat()">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- add Status modal -->
    <div class="modal fade" id="addStatusModal" tabindex="-1" aria-labelledby="statusModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light" id="statusModal">
                        Add new Status
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" id="addStatForm">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Status name</label>
                            <input type="text" class="form-control" id="inputStatName" placeholder="input name of the Status">
                        </div>
                    </form>

                    <div id="statusWrnAlert">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" data-bs-dismiss="modal" onclick="addStat()">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- add Inventory modal -->
    <div class="modal fade" id="addInventoryModal" tabindex="-1" aria-labelledby="addInvModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light">
                        Add new Inventory
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" id="addInvForm">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Inventory name</label>
                            <input name="inventoryName" type="text" class="form-control" id="inputInvName" placeholder="Name of the Inventory" maxlength="32">
                        </div>
                    </form>

                    <div id="invWrnAlrt">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-bs-dismiss="modal" class="btn btn-dark" onclick="addInv()">
                        + Add
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- delete Inventory modal -->
    <div class="modal fade" id="deleteInventoryModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="deleteItemLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="deleteInvLabel">Delete Inventory</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-2" id="dltInvNotif">
                        Are you sure you want to delete this Inventory?
                    </div>

                    <div id="invAlrtDel">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal" onclick="deleteInventory()" id="yesDel">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- edit Inventory modal -->
    <div class="modal fade" id="editInventoryModal" tabindex="-1" aria-labelledby="editInv" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light" id="editInv">
                        Edit Inventory
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Inventory Name</label>
                            <input type="text" class="form-control mb-3" id="prevInvName" placeholder="" readonly>

                            <label for="exampleFormControlInput1" class="form-label">New Inventory Name</label>
                            <input type="text" class="form-control" id="newInvNameInput" placeholder="New Inventory Name..">
                        </div>

                        <div class="mb-3">
                            <div class="row g-3">
                                <div class="col">
                                    <label for="exampleFormControlInput1" class="form-label">Category list</label>
                                    <ul class="list-group overflow-scroll border border-radius" style="max-height: 200px;" id="InvCatList">

                                    </ul>
                                </div>
                                <div class="col">
                                    <label for="exampleFormControlInput1" class="form-label">Status list</label>
                                    <ul class="list-group overflow-scroll border border-radius" style="max-height: 200px;" id="InvStatList">

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </form>

                    <div id="editWrnAlrt">

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" data-bs-dismiss="modal" onclick="editInventory()">
                        Edit Inventory
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- this is where the barcode will appear and be downloaded -->
    <div id="box">

    </div>

    <!-- Script functionalities -->
    <script src="../js/custom js/modalscripts.js"></script>
    <script src="../js/custom js/fileNavigationscript.js"></script>
    <script>
        // for initializing
        const invNameContent = document.getElementById('invName');
        const invBarContent = document.getElementById('itmBarcodeList');
        getInventoryList();

        // for initializing the bootstrap tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

        // shows the alerts of the items
        const alertPlaceholder = document.getElementById('liveAlertPlaceholder')

        const alert = (message, type) => {
            const wrapper = document.createElement('div')
            wrapper.innerHTML = [
                `<div class="alert alert-${type} alert-dismissible" role="alert">`,
                `   <div>${message}</div>`,
                '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
                '</div>'
            ].join('')

            alertPlaceholder.append(wrapper)
        }

        // const alertTrigger = document.getElementById('liveAlertBtn')
        // if (alertTrigger) {
        //     alertTrigger.addEventListener('click', () => {
        //         alert('Nice, you triggered this alert message!', 'success')
        //     })
        // }

        // gets the current selected inventory to show the proper status and category list
        var slctInv = document.getElementById("selectInv");
        slctInv.addEventListener("change", function() {
            var selectedInv = document.getElementById("selectInv").value;
            requestResponseOutputAjax("selectCat", "getInventoryCategory.php", selectedInv);
            requestResponseOutputAjax("selectStat", "getInventoryStatus.php", selectedInv);
        });

        // loads the inventory list of items
        function loadInventoryDetails(evt, contentName, inv_id) {
            inventoryId = inv_id;
            inventoryName = contentName;
            document.getElementById("inventoryName").innerText = contentName;

            // Declare all variables
            var i, tabcontent;

            // Get all elements with class="tabcontent" and hide them
            tabcontent = document.getElementsByClassName("tableContent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            //get all the forms and reset all of them that is not selected
            tabform = document.getElementsByClassName("invform");
            for (i = 0; i < tabform.length; i++) {
                tabform[i].reset();
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            document.getElementById(contentName).style.display = "block";

            // Get all elements with class="tablinks" and remove the class "active"
            var item = document.getElementsByClassName("sidebar-list");
            for (i = 0; i < item.length; i++) {
                item[i].className = item[i].className.replace("text-light", "");

            }

            var catList = document.querySelectorAll("#list" + inv_id);
            for (i = 0; i < catList.length; i++) {
                catList[i].className = catList[i].className.replace("text-secondary", " text-light");

            }
            var allcatlist = document.querySelectorAll(".category");
            for (i = 0; i < allcatlist.length; i++) {
                if (allcatlist[i].id != "list" + inv_id) {
                    allcatlist[i].className = allcatlist[i].className.replace("text-light", " text-secondary");
                }
                // console.log(allcatlist[i].id );
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            evt.currentTarget.className += " text-light";
        }

        // gets the list of items base from the category selected
        function getItemListByCategory(categoryId, inv_id) {
            var parameters = {
                "ItmCat": categoryId,
                "ItmInv": inv_id
            };

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("item_table" + inv_id).innerHTML = this.responseText;
                }
            };

            xmlhttp.open("POST", "get_itemsByCategory.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send(createParameterString(parameters));
        }

        //creates a parameter to pass on the ajax so the php file can use
        function createParameterString(parameters) {
            // Create parameter string
            var parameterString = "";
            var isFirst = true;
            for (var index in parameters) {
                if (!isFirst) {
                    parameterString += "&";
                }
                parameterString += encodeURIComponent(index) + "=" + encodeURIComponent(parameters[index]);
                isFirst = false;
            }

            return parameterString;
        }

        // downloads an img form of the barcode
        var itmName = "";
        var bcCode = 0;

        function downloadBarcodeImg(itemName, barcode) {
            itmName = itemName;
            bcCode = barcode;
            const box = `
            <div class="card" data-bs-toggle="tooltip" data-bs-title="download Barcode" id="${itemName}" style="width: 16rem;" >
                <div class="card-body text-center">
                    <svg id="barcodeimg" class="barcode"></svg>
                    <p class="card-title m-0">${itemName}</p>
                </div>
            </div>`;
            document.getElementById("box").innerHTML = box;

            JsBarcode("#barcodeimg", bcCode, {
                format: "ITF",
                width: 1.5,
                height: 80,
            });
            console.log(itemName + " " + barcode);

            html2canvas(document.getElementById(itemName)).then(canvas => {
                // document.body.appendChild(canvas);
                var img = canvas.toDataURL();
                downloadURI(img, itemName + ".png");

            });
        }

        function downloadURI(uri, name) {
            var link = document.createElement("a");

            link.download = name;
            link.href = uri;
            document.body.appendChild(link);
            link.click();
            link.remove();
            document.getElementById("box").innerHTML = ""
        }



        // for the sidebar functionality
        var sidebar = document.getElementById("sidebar");
        var content = document.getElementById("content_section");

        function sidebar_open() {
            sidebar.classList.remove("close");
            sidebar.classList.add("open");

            content.classList.remove("cm-open");
            content.classList.add("cm-close");

        }

        function sidebar_close() {
            sidebar.classList.remove("open");
            sidebar.classList.add("close");

            content.classList.remove("cm-close");
            content.classList.add("cm-open");
        }
    </script>

</body>

</html>