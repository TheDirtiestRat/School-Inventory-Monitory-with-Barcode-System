<?php
require "connect_db.php";
require 'session.php';

$itm_id = $_POST['ItmId'];
$itm_s = $_POST['CurItmStat'];
$is_brr = $_POST['IsBrr'];

$sql = "SELECT * FROM `item` WHERE `itemId` = $itm_id AND `statusId` = $itm_s";
$result = mysqli_query($conn, $sql);

// if there is no status for that items insert a new one
if (mysqli_num_rows($result) > 0) {
    // $sql = "UPDATE `Item` SET `statusId` = $itm_s WHERE itemId = $itm_id;";
    // $sql = "UPDATE `Item` SET `itemAmount` =  `itemAmount` + 1 WHERE itemId = $itm_id;";
    $sql2 = "UPDATE `Item` SET `itemAmount` = IF(`itemAmount` > 0, `itemAmount` - 1, 0) WHERE statusId IN (SELECT statusId FROM status WHERE statusId != $itm_s) AND `itemBarcode` = (SELECT itemBarcode FROM item WHERE itemId = $itm_id);
            UPDATE `Item` SET `itemAmount` = `itemAmount` + 1 WHERE statusId = $itm_s AND `itemId` = $itm_id;";

    if (mysqli_multi_query($conn, $sql2)) {
        echo '<div class="alert alert-success" role="alert">
                Item is Updated
            </div>';
    
        if ($is_brr == 1) {
            $sql3 = "UPDATE `Transaction` SET `transactionComplete` = 0 WHERE itemId = $itm_id";
            
            if (mysqli_query($conn, $sql3)) {
                echo '<div class="alert alert-success" role="alert">
                    Transaction has been updated
                </div>';
            }
        }
    
    } else {
        echo '<div class="alert alert-danger" role="alert">
                Failed to Update Item!
            </div>';
    }
} else {

    $sql = "UPDATE `Item` SET `itemAmount` = IF(`itemAmount` > 0, `itemAmount` - 1, 0)  WHERE statusId = $itm_s AND `itemId` = $itm_id;
    INSERT INTO `item`(`itemId`, `itemName`, `itemSpecification`, `itemAmount`, `itemBarcode`, `categoryId`, `statusId`, `inventoryId`, `itemDate`, `IsArchive`)
    SELECT null, `itemName`, `itemSpecification`, 1, `itemBarcode`, `categoryId`, $itm_s, `inventoryId`, `itemDate`, `IsArchive` FROM item WHERE itemId = $itm_id;";

    if (mysqli_multi_query($conn, $sql)) {
        echo '<div class="alert alert-success" role="alert">
                Item is Updated, new record added
            </div>';
    }
}



// $sql = "UPDATE `Item` SET `statusId` = $itm_s WHERE itemId = $itm_id;";

// if (mysqli_query($conn, $sql)) {
//     echo '<div class="alert alert-success" role="alert">
//             Item is Updated
//         </div>';

//     if ($is_brr == 1) {
//         // $sql = "DELETE FROM `Transaction` WHERE itemId = $itm_id";
//         $sql = "UPDATE `Transaction` SET `transactionComplete` = 0 WHERE itemId = $itm_id";
        
//         if (mysqli_query($conn, $sql)) {
//             echo '<div class="alert alert-success" role="alert">
//                 Transaction has been updated
//             </div>';
//         }
//     }

// } else {
//     echo '<div class="alert alert-danger" role="alert">
//             Failed to Update Item!
//         </div>';
// }
