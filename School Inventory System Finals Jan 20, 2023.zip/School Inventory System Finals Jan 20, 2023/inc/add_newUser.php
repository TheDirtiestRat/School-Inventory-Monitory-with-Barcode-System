<?php

require "connect_db.php";
require 'session.php';

if ($user != "admin") {
    header("Location: index.php?error=Authorized access only");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add new Users</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <!--Nav Bar-->
    <?php include "navbar.php"; ?>

    <!-- Users list -->
    <section class="nb-padding">

        <div class="container p-md-4">

            <?php if (isset($_GET['alert'])) { ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $_GET['alert']; ?>
                </div>
            <?php } ?>

            <?php if (isset($_GET['error'])) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $_GET['error']; ?>
                </div>
            <?php } ?>

            <!-- <div class="alert alert-success" role="alert">
                New User added (name of the user name)!
            </div> -->

            <?php

            $sql = "SELECT `userId`, `userName`, `userPass`, `userFirstName`, `userLastName`, `userEmail`, `userContact`, `userAddress`, `userOccupation`, `userPictureFile` FROM `User` WHERE userId != 1;";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    $userImg = "";

                    if ($row['userPictureFile'] == "userImg.png") {
                        $userImg = "../assets/userImg.png";
                    } else {
                        $userImg = "../files/uploads/" . $row['userPictureFile'];
                    }

                    echo '<div class="card mb-3">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 text-center d-flex align-items-center justify-content-center">
                                <div class="">
                                    <img src=' . $userImg . ' class="border border-secondary rounded-circle proListImg" alt="..." id="">
                                    <p>' . $row['userName'] . '</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div>
                                    <p>' . $row['userFirstName'] . '</p>
                                    <p>' . $row['userLastName'] . '</p>
                                    <p>' . $row['userEmail'] . '</p>
                                </div>
                            </div>
    
                            <div class="col-md-5">
                                <div>
                                    <p>' . $row['userContact'] . '</p>
                                    <p>' . $row['userOccupation'] . '</p>
                                    <p>' . $row['userAddress'] . '</p>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-danger float-md-end align-items-center" data-bs-toggle="modal" data-bs-target="#deleteUserModal" onclick="getUserId(' . $row['userId'] . ','. "'" . $row['userName'] . "'" . ')">Delete User</button>
                    </div>
                </div>';
                }
            } else {
                echo '<div class="card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col text-center d-flex align-items-center justify-content-center">
                            <p>No Users</p>
                        </div>
                    </div>
                </div>
            </div>';
            }
            ?>

            <div class=" text-center">
                <button type="button" class="btn btn-dark btn-lg" data-bs-toggle="modal" data-bs-target="#addUserModal">Add new user</button>
            </div>

        </div>
    </section>

    <!-- Modal -->
    <!-- Add user modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark text-light">
                    <h1 class="modal-title fs-5" id="addUserModal">Add New User</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="add_user.php" method="POST">
                    <div class="modal-body">
                        <div class="">
                            <label for="validationDefaultUsername" class="form-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-text" id="inputGroupPrepend2">@</span>
                                <input type="text" class="form-control" name="userName" id="validationDefaultUsername" aria-describedby="inputGroupPrepend2" required>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label for="validationDefault01" class="form-label">First name</label>
                                <input type="text" class="form-control" name="firstName" id="validationDefault01" value="" required>
                            </div>
                            <div class="col-md-6">
                                <label for="validationDefault02" class="form-label">Last name</label>
                                <input type="text" class="form-control" name="lastName" id="validationDefault02" value="" required>
                            </div>
                        </div>

                        <div class="">
                            <label for="validationDefaultPassword" class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="password" id="validationDefaultPassword" aria-describedby="inputGroupPrepend2" required>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-dark">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- delete user modal -->
    <div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark text-light">
                    <h1 class="modal-title fs-5" id="deleteUserModal">Delete New User</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="delete_user.php" method="POST">
                    <div class="modal-body">
                        
                        Do you want to delete <strong><span id="u_name"></span></strong>?

                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        <button type="submit" name="deleteConfirm" id="deleteConfirm" class="btn btn-dark" value="0">Yes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Script functionality -->
    <script>
        function getUserId (user_id, user_name) {
            document.getElementById("u_name").innerText = user_name;
            document.getElementById("deleteConfirm").value = user_id;
        }
    </script>
</body>

</html>