<?php

require "connect_db.php";
require 'session.php';

$q = $_REQUEST['q'];

$sql = "SELECT statusId, statusName FROM `Status` WHERE inventoryId = $q;";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) { 
    while ($row = mysqli_fetch_array($result)) {
        echo '<option value="'; echo $row['statusId']; echo'">'; echo $row['statusName']; echo '</option>';
    }
} else {
    echo'<option selected>No Status</option>';
}
?>