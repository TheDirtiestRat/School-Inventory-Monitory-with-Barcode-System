<?php
require "connect_db.php";
require 'session.php';

$src = $_POST['search'];
$itm_i = $_POST['inv'];

$src = htmlspecialchars($src);
$src = mysqli_real_escape_string($conn, $src);

$sql = "SELECT itemId, itemName, itemAmount, `itemBarcode`, Category.categoryName, Status.statusName, itemDate FROM `Item` 
INNER JOIN Category ON Item.categoryid = Category.categoryid 
INNER JOIN Status ON Item.statusId = Status.statusId 
WHERE itemName LIKE '%$src%' AND Item.inventoryId = $itm_i AND Item.IsArchive != 1;;";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) { 
    while ($row = mysqli_fetch_array($result)) {
        $index++;
        echo '<tr>';
        echo '<td class="align-middle">
            <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="' . $row['itemId'] . '" aria-label="...">
            </td>';
        echo '<th class="align-middle">' . $index . '</th>';
        echo '<td class="align-middle">' . $row['itemName'] . '</td>';
        echo '<td class="align-middle">' . $row['itemAmount'] . '</td>';
        echo '<td class="align-middle">' . $row['statusName'] . '</td>';
        echo '<td class="align-middle">' . $row['categoryName'] . '</td>';
        echo '<td class="align-middle"><a href="#" data-bs-toggle="tooltip" data-bs-title="download barcode" onclick="downloadBarcodeImg(' . "'" . $row['itemName'] . "'" . ', ' . $row['itemBarcode'] . ')">';
        echo '<img src="../assets/download-solid.svg" width="16px" alt="" class="">';
        echo '</a></td>';
        echo '<td class="align-middle">' . $row['itemBarcode'] . '</td>';

        echo '<td class="text-end">';
        echo '<a href="#"  data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
        echo '<img data-bs-toggle="tooltip" data-bs-title="edit item" src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
        echo '</a>';
        echo '</td>';
        echo '</tr>';
    }
    // while ($row = mysqli_fetch_array($result)) {
    //     echo '<tr>';
    //     echo '<td class="align-middle">
    //             <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="'; echo $row['itemId']; echo '" aria-label="...">
    //         </td>';
    //     echo '<th class="align-middle">'; echo $row['itemId']; echo '</th>';
    //     echo '<td class="align-middle">'; echo $row['itemName']; echo '</td>';
    //     echo '<td class="align-middle">'; echo $row['statusName']; echo '</td>';
    //     echo '<td class="align-middle">'; echo $row['categoryName']; echo '</td>';
    //     echo '<td class="align-middle">'; echo $row['itemDate']; echo '</td>';
    //     echo '<td class="text-end">';
    //     echo '<a href="" data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
    //     echo '<img src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
    //     echo '</a>';
    //     echo '</td>';
    //     echo '</tr>';
    // }
}
// else { 
//     echo '<tr>';
//     echo '<td colspan="6">';
//     echo '  <h1 class="text-secondary p-3 text-center">No Item matched the search</h1>';
//     echo '</td>';
//     echo '</tr>'; 
// }

?>