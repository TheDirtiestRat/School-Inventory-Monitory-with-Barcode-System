<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <title>Log-in</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <section class=" m-2 d-flex align-items-center justify-content-center" style="height: 100vh;">
        <form action="login.php" method="post" name="loginForm">
            <div class=" container-fluid border border-radius p-4" style="width: 500px;">

                <div class="">
                    <p class="lead m-0" id="demo">
                        School Inventory Monitoring with Barcode System
                    </p>
                    <h1>Log-in</h1>
                </div>

                <hr>

                <div class="mb-3">
                    <label class="form-label">User Name</label>
                    <input type="text" class="form-control" id="userName" name="userName" placeholder="User Name">
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" id="passWord" name="passWord" placeholder="Password">
                </div>

                <?php if (isset($_GET['error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $_GET['error']; ?>
                    </div>
                <?php } ?>

                <hr>

                <div class="">
                    <button type="submit" class="btn btn-dark">Log-in</button>
                </div>
            </div>
        </form>
    </section>

    <!-- <div class="d-flex align-items-center justify-content-center max-screen-height">
        <div class="  p-5 m-0 text-center" style="width: 360px;">
            <img src="../assets/aclc logo.svg" width="100%" alt="aclc logo">
        </div> 
        <div class=" container-md border border-radius p-5 shadow m-0" style="max-width: 480px;">
            <form action="login.php" method="post" name="loginForm">
                <p class="lead m-0" id="demo">
                    School Inventory System
                </p>
                <div class="">
                    <h1>Log-in</h1>
                </div>
                <hr>
                <div class="mb-3">
                    <label class="form-label">User Name</label>
                    <input type="text" class="form-control" id="userName" name="userName" placeholder="User Name">
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" id="passWord" name="passWord" placeholder="Password">
                </div>

                <?php if (isset($_GET['error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $_GET['error']; ?>
                    </div>
                <?php } ?>
                <hr>
                <div class="">
                    <button type="submit" class="btn btn-dark">Log-in</button>
                </div>
            </form>
        </div>
    </div> -->

</body>

</html>