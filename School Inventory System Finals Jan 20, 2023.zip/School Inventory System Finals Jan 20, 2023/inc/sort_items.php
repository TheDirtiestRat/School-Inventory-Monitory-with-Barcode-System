<?php
require "connect_db.php";
require 'session.php';

$ord = $_POST['ItmOrder'];
$itm_i = $_POST['ItmInv'];

$sql = "SELECT itemId, itemName, Category.categoryName, Status.statusName, itemDate FROM `Item` 
INNER JOIN Category ON Item.categoryId = Category.categoryId 
INNER JOIN Status ON Item.statusId = Status.statusId
WHERE Item.inventoryId = $itm_i ORDER BY $ord ASC";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) { 
    while ($row = mysqli_fetch_array($result)) {
        echo '<tr>';
        echo '<td class="align-middle">
                <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="'; echo $row['itemId']; echo '" aria-label="...">
            </td>';
        echo '<th class="align-middle">'; echo $row['itemId']; echo '</th>';
        echo '<td class="align-middle">'; echo $row['itemName']; echo '</td>';
        echo '<td class="align-middle">'; echo $row['statusName']; echo '</td>';
        echo '<td class="align-middle">'; echo $row['categoryName']; echo '</td>';
        echo '<td class="align-middle">'; echo $row['itemDate']; echo '</td>';
        echo '<td class="text-end">';
        echo '<a href="" data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
        echo '<img src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
        echo '</a>';
        echo '</td>';
        echo '</tr>';
    }
}else { 
    echo '<tr>';
    echo '<td colspan="6">';
    echo '  <h1 class="text-secondary p-3 text-center">No Items Sort</h1>';
    echo '</td>';
    echo '</tr>'; 
}

?>