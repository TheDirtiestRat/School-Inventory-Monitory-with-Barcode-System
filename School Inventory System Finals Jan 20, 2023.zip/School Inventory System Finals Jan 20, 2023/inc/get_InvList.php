<?php
require "connect_db.php";
require 'session.php';

$q = $_REQUEST['q'];

$sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $_SESSION[user_id];";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $id = $row['inventoryId'];

        echo '<li>';
        echo '<a class="btn btn-dark w-100 text-start" data-bs-toggle="collapse" id="dltBtn'; echo $row['inventoryId']; echo '" href="#col'; echo $row['inventoryId']; echo '" role="button" aria-expanded="false" aria-controls="collapse" onclick="getInventoryDetails('; echo $row['inventoryId']; echo ')">';
        echo    '<img src="../assets/caret-down-white.svg" width="8px" alt="" class="">';
        echo    '<strong class="ps-1" id="name'; echo $id; echo '">';
        echo         $row['inventoryName'];
        echo    '</strong>';
        echo '</a>';
        echo '</li>';


        $sql2 = "SELECT categoryId, categoryName, inventoryId FROM `Category` WHERE inventoryId = $id;";
        $res = mysqli_query($conn, $sql2);


        echo '<div class="collapse" id="col'. $id .'">';
        
        echo '<div style="margin-left: 1rem;">';
        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_array($res)) {
                if ($id == $row['inventoryId']) {
                    
                    echo '<a href="#'; $row['categoryName']; echo '"class="btn btn-dark w-100 text-start">';
                    echo     $row['categoryName'];
                    echo '</a>';
                    
                }
            }
        }
        echo "</div>";
        
        echo '<div class="row">';
        echo '<div class="col text-center w-50 d-flex justify-content-center">';
        echo '<a href="#" class="btn btn-dark w-25" data-bs-toggle="modal" data-bs-target="#deleteInventory" onclick="onDelInv('; echo $row['inventoryId']; echo ')">'; echo '<img src="../assets/trash-can-white.svg" width="8px" alt="" class="icon me-1"> </a>';
        echo '<a href="#" class="btn btn-dark w-25" data-bs-toggle="modal" data-bs-target="#editInv" onclick="getCatAndStatList()"> <img src="../assets/pen-to-square-white.svg" alt="" class="icon pe-1"> </a>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo '<h3 class=" text-secondary text-center">No Inventories added yet </h3>';
}
?>