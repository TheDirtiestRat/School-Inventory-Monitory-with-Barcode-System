<?php

require "connect_db.php";
require 'session.php';

$q = $_REQUEST['q'];

$sql = "SELECT Item.itemId, Item.itemName, itemAmount, `itemBarcode`, Category.categoryName, Status.statusName, Item.itemDate, Inventory.inventoryName FROM `Item` 
INNER JOIN Category ON Item.categoryId = Category.categoryId 
INNER JOIN Status ON Item.statusId = Status.statusId 
INNER JOIN Inventory ON Item.inventoryId = Inventory.inventoryId WHERE Item.inventoryId = $q AND Item.IsArchive != 1;";

$result = mysqli_query($conn, $sql);

// while ($row = mysqli_fetch_array($res)) {
//     $index++;
//     echo '<tr>';
//     echo '<td class="align-middle">
//             <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="' . $row['itemId'] . '" aria-label="...">
//             </td>';
//     echo '<th class="align-middle">' . $index . '</th>';
//     echo '<td class="align-middle">' . $row['itemName'] . '</td>';
//     echo '<td class="align-middle">' . $row['itemAmount'] . '</td>';
//     echo '<td class="align-middle">' . $row['statusName'] . '</td>';
//     echo '<td class="align-middle">' . $row['categoryName'] . '</td>';
//     echo '<td class="align-middle"><a href="#" data-bs-toggle="tooltip" data-bs-title="download barcode" onclick="downloadBarcodeImg(' . "'" . $row['itemName'] . "'" . ', ' . $row['itemBarcode'] . ')">';
//     echo '<img src="../assets/download-solid.svg" width="16px" alt="" class="">';
//     echo '</a></td>';
//     echo '<td class="align-middle">' . $row['itemBarcode'] . '</td>';

//     echo '<td class="text-end">';
//     echo '<a href="#"  data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
//     echo '<img data-bs-toggle="tooltip" data-bs-title="edit item" src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
//     echo '</a>';
//     echo '</td>';
//     echo '</tr>';
// }

$index = 0;
while ($row = mysqli_fetch_array($result)) {
    $index++;
    echo '<tr>';
    echo '<td class="align-middle">
            <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="' . $row['itemId'] . '" aria-label="...">
            </td>';
    echo '<th class="align-middle">' . $index . '</th>';
    echo '<td class="align-middle">' . $row['itemName'] . '</td>';
    echo '<td class="align-middle">' . $row['itemAmount'] . '</td>';
    echo '<td class="align-middle">' . $row['statusName'] . '</td>';
    echo '<td class="align-middle">' . $row['categoryName'] . '</td>';

    echo '<td class="align-middle">';
    echo '<a href="#"  data-bs-toggle="collapse" data-bs-target="#colps' . $row['itemId'] . '" aria-expanded="false" aria-controls="collapseExample">';
    echo '<img data-bs-toggle="tooltip" data-bs-title="show item history" src="../assets/caret-down-solid.svg" width="16px" alt="" class="">';
    echo '</a>';
    echo '</td>';

    echo '<td class="align-middle"><a href="#" data-bs-toggle="tooltip" data-bs-title="download barcode" onclick="downloadBarcodeImg(' . "'" . $row['itemName'] . "'" . ', ' . $row['itemBarcode'] . ')">';
    echo '<img src="../assets/download-solid.svg" width="16px" alt="" class="">';
    echo '</a></td>';
    echo '<td class="align-middle">' . $row['itemBarcode'] . '</td>';

    echo '<td class="text-end">';
    echo '<a href="#"  data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
    echo '<img data-bs-toggle="tooltip" data-bs-title="edit item" src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
    echo '</a>';
    echo '</td>';
    echo '</tr>';

    echo '
    <tr>
        <td colspan="10" class="collapse" id="colps' . $row['itemId'] . '">
            <div class="card card-body">
                <table class="table table-hover">
                    <thead>
                        <th>Item</th>
                        <th>Inventory</th>
                        <th>Added</th>
                        <th>Modified</th>
                        <th></th>
                    </thead>
                    <tbody>';
                    $id = $row['itemId'];
                    $sql4 = "SELECT `historyId`, Item.itemName, Inventory.inventoryName, `dateAdded`, `dateModified`, `dateRemoved` FROM `ItemHistory`
                    INNER JOIN Item ON ItemHistory.itemId = Item.itemId
                    INNER JOIN Inventory ON ItemHistory.itemId = Inventory.inventoryId
                    WHERE ItemHistory.itemId = $id";

                    $res2 = mysqli_query($conn, $sql4);

                    if (mysqli_num_rows($res2) > 0) {
                        while ($row = mysqli_fetch_array($res2)) {
                            echo '<tr>
                                    <td>'. $row['itemName'] .'</td>
                                    <td>'. $row['inventoryName'] .'</td>
                                    <td>'. $row['dateAdded'] .'</td>
                                    <td>'. $row['dateModified'] .'</td>
                                </tr>';
                        }
                    }
                    echo '</tbody>
                </table>
            </div>
        </td>
    </tr>';
}

// else {
//     echo '<tr>';
//     echo '<td colspan="6">';
//     echo '<h3 class=" text-secondary text-center">No Inventory added</h3>';
//     echo '</td>';
//     echo '</tr>';
// }
