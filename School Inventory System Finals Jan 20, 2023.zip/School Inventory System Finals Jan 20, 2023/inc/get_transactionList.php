<?php
require "connect_db.php";
require 'session.php';

$u_id = $_SESSION['userId'];

if ($u_id == 1) {
    $sql = "SELECT `transactionId`, `transactionName`, `transactionDate`, Item.itemName, `userId`, `transactionComplete` FROM `Transaction` 
    LEFT JOIN Item on Transaction.itemId = Item.itemId WHERE `transactionComplete` = 1;";
}else {
    $sql = "SELECT `transactionId`, `transactionName`, `transactionDate`, Item.itemName, `userId`, `transactionComplete` FROM 
    `Transaction` LEFT JOIN Item on Transaction.itemId = Item.itemId
    WHERE `userId` = $u_id AND `transactionComplete` = 0;";
}


$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        echo '<tr>
        <th scope="row">'. $row['transactionId'] .'</th>
        <td class="align-middle">'. $row['transactionName'] .'</td>
        <td class="align-middle">'. $row['itemName'] .'</td>
        <td class="align-middle">'. $row['transactionDate'] .'</td>
        </tr>';
    }
} else {
    echo '<tr>
    <td colspan="4" class="text-center text-secondary"><h1>No Transactions today</h1></td>
    </tr>';
}

?>