<?php

require "connect_db.php";
require 'session.php';

$inv_id = $_POST['ItmInv'];

$sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $_SESSION[user_id];";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $in_id = $row['inventoryId'];

        echo '<div class="barcodesContent" id="bc1">';
        echo '<div class="row mb-3">';
        echo '<div class="col"><h3 id="invName">' . $row['inventoryName'] . '</h3></div>';
        echo '<div class="col-3 text-end">';
        echo '<a id="prntBtn" onclick="printBarcodes(';
        echo "'invBarcodes'";
        echo ')" data-bs-toggle="tooltip" data-bs-title="Print All Barcodes">
         <img src="../assets/download-solid.svg" alt="" class="icon-md">
         </a>
         </div>
         </div>';

        echo '<div id="invBarcodes" class="p-2 border border-radius">
         <div class="row" id="itmBarcodeList">';


        $sql2 = "SELECT Item.itemId, Item.itemName FROM `Item` WHERE Item.inventoryId = $in_id;";

        $res = mysqli_query($conn, $sql2);

        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_array($res)) {

                echo '<div class="col-4" id="barprnt'; echo "'"; echo $row['itemId']; echo "'"; echo '" class="barcode">';
                echo '<div class="text-center">';
                echo '<a id="prntBtn" onclick="printBarcode('; echo "'barprnt"; echo $row['itemId']; echo "'"; echo ')" data-bs-toggle="tooltip" data-bs-title="Print Barcode">';
                echo '<svg id="barcode'. $row['itemId'] .'"></svg>';
                echo '</a>';
                echo '<p class="">'. $row['itemName'] .'</p>';
                echo '</div></div>';

                echo '<script>
                    JsBarcode("#barcode'. $row['itemId'] .'", "123456789012", {
                    format: "UPC",
                    width: 1.5,
                    height: 80,
                    });
                    </script>';

            }
        } else {
            echo '<h3 class=" text-secondary text-center">No Barcodes generated</h3>';
        }


        echo '</div>
            </div>';
        echo '</div>';
    }
} else {
    echo '<h3 class=" text-secondary text-center">No Barcodes generated</h3>';
}
