<?php
require "connect_db.php";
require 'session.php';

$itm_n = $_POST['ItmName'];
$itm_sp = $_POST['itemSpecify'];
$itm_c = $_POST['ItmCat'];
$itm_s = $_POST['ItmStat'];
$itm_i = $_POST['ItmInv'];
$itm_amount = $_POST['ItmAmount'];

$sql = "SELECT `itemName` FROM `Item` WHERE `itemName` = '$itm_n' AND `inventoryId` = $itm_i;";
$result = mysqli_query($conn, $sql);

// if it finds that item exist, it'll return false
if (mysqli_num_rows($result) > 0) {
        echo '<div class="alert alert-danger" role="alert">
            Item already exist in the Inventory
        </div>';
        // header("Location: fileMaintenance.php?error=Item already exist in the Inventory");
} else {
        $barcode = abs(crc32(uniqid()));

        $sql = "INSERT INTO `Item` (`itemId`, `itemName`, `itemSpecification`, `itemAmount`, `itemBarcode`, `categoryId`, `statusId`, `inventoryId`, `itemDate`, `IsArchive`)
                VALUES(NULL, '$itm_n', '$itm_sp', '$itm_amount', NULL, '$itm_c', '$itm_s', '$itm_i', CURRENT_DATE(), 0);
                UPDATE `Item` SET `itemBarcode` = RPAD($barcode, 12, '0') WHERE `Item`.`itemId` = (SELECT LAST_INSERT_ID());
                INSERT INTO `ItemHistory`(`historyId`, `itemId`, `inventoryId`, `dateAdded`, `dateModified`, `dateRemoved`) 
                VALUES (NULL, (SELECT LAST_INSERT_ID()), $itm_i, CURRENT_DATE(), CURRENT_DATE(), NULL)";

        if (mysqli_multi_query($conn, $sql)) {
                echo '<div class="alert alert-success" role="alert">
                    Item '. $itm_n .' Added successfully
                </div>';
                // header("Location: fileMaintenance.php?alert=Item is added");
        } else {
                echo '<div class="alert alert-danger" role="alert">
                    Failed to Add Item, Invalid Input!
                </div>';
                // header("Location: fileMaintenance.php?error=Failed to add item");
        }
}
