<?php
require "connect_db.php";
require 'session.php';


if(isset($_POST['items'])){
    
    $all = implode(",", $_POST['items']);
    // $sql = "DELETE FROM `Item` WHERE itemId IN ($all);";
    $sql = "UPDATE `Item` SET `IsArchive`= 1 WHERE itemId IN ($all);
            UPDATE `ItemHistory` SET `dateRemoved`= CURRENT_DATE WHERE `itemId` IN ($all);";

    if ($res = mysqli_multi_query($conn, $sql)) {
        echo '<div class="alert alert-success" role="alert">
                the Selected item is remove successfully.
            </div>';
    } else {
        if (strpos(mysqli_error($conn), "a foreign key constraint fails")) {
            echo '<div class="alert alert-danger" role="alert">
                Failed to remove Item, items is still in used in transaction
            </div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">
                Failed to remove Item '. $all .'
            </div>';
        }
        
    }
}

?>