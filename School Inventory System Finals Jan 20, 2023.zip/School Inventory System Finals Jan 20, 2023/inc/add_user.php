<?php
require "connect_db.php";
require 'session.php';

$uname = $_POST['userName'];
$fname = $_POST['firstName'];
$lname = $_POST['lastName'];
$pass = $_POST['password'];

$sql = "INSERT INTO `User` (`userId`, `userName`, `userPass`, `userFirstName`, `userLastName`, `userEmail`, `userContact`, `userAddress`, `userOccupation`, `userPictureFile`) VALUES (NULL, '$uname', '$pass', '$fname', '$lname', '', NULL, '', '', 'userImg.png');";

if (mysqli_query($conn, $sql)) {
    echo "User Added successfully";

    header("Location: add_newUser.php?alert=User Added successfully");
} else {
    echo "Adding User failed";

    header("Location: add_newUser.php?error=Adding User failed");
}
