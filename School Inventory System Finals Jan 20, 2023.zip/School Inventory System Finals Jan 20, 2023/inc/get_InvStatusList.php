<?php

require "connect_db.php";
require 'session.php';

$q = $_REQUEST['q'];

$sql2 = "SELECT statusId, statusName FROM `Status` WHERE inventoryId = $q;";

$res = mysqli_query($conn, $sql2);

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_array($res)) {
        echo '<li class="list-group-item">'; echo $row['statusName']; echo '
            <a class="float-end" href="#" data-bs-toggle="" data-bs-target="" id="dltStatBtn" onclick="delStat('; echo $row['statusId']; echo ')">
                <img src="../assets/trash-solid.svg" alt="" width="16px" class="">
            </a>
            </li>';
    }
} else {
    echo '<li class="list-group-item text-secondary">No Status</li>';
}
?>