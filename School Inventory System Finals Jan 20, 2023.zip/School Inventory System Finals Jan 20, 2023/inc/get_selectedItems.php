<?php

require "connect_db.php";
require 'session.php';

$q = $_REQUEST['q'];

$sql = "SELECT Item.itemId, Item.itemName, Category.categoryName, Status.statusName, Item.itemDate, Inventory.inventoryName FROM `Item` 
INNER JOIN Category ON Item.categoryId = Category.categoryId 
INNER JOIN Status ON Item.statusId = Status.statusId 
INNER JOIN Inventory ON Item.inventoryId = Inventory.inventoryId WHERE Item.inventoryId = $q;";

$result = mysqli_query($conn, $sql);

?>