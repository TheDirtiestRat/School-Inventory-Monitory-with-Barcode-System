<?php
require "connect_db.php";
require 'session.php';

$stat_n = $_POST['StatName'];
$stat_i = $_POST['StatInv'];

if ($stat_n == "") {
    echo '<div class="alert alert-danger" role="alert">
        Status name is empty
        </div>';
    return;
}

$sql = "INSERT INTO `Status` (`statusId`, `statusName`, `inventoryId`) VALUES (NULL, '$stat_n', '$stat_i');";

if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-success" role="alert">
            New Status is Added successfully
        </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Add new Status, Invalid Input!
        </div>';
}

?>