<?php
require "connect_db.php";
require 'session.php';

$u_id = $_SESSION['userId'];

if ($u_id == 1){
    $sql = "SELECT COUNT(*) FROM `Transaction` GROUP BY itemId";
}else {
    $sql = "SELECT COUNT(*) FROM `Transaction` WHERE userId = $u_id GROUP BY itemId";
}

$result = mysqli_query($conn, $sql);

$row = mysqli_num_rows($result);
$brr_items = $row;

echo '<span class="pe-4">
<h1 class="m-0" id="noBrrItms">'. $row .'</h1>
<strong class="p-1">Borrowed Items</strong>
</span>';

if ($u_id == 1) {
    $sql = "SELECT COUNT(`itemId`) AS remainingItems FROM `Item` WHERE `itemId` NOT IN (SELECT itemId FROM Transaction) AND `inventoryId` IN (SELECT inventoryId FROM Inventory);";
}else {
    $sql = "SELECT COUNT(`itemId`) AS remainingItems FROM `Item` WHERE `itemId` NOT IN (SELECT itemId FROM Transaction) AND `inventoryId` IN (SELECT inventoryId FROM Inventory WHERE userId = $u_id);";
}

$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

echo '<span class="pe-4 float-end">
<h1 class="m-0">'. $row['remainingItems'] .'</h1>
<strong class="p-1">Remaining Items</strong>
</span>';

?>