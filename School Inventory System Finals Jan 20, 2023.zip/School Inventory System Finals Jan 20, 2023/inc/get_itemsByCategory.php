<?php
require "connect_db.php";
require 'session.php';

$categoryId = $_POST['ItmCat'];
$itm_i = $_POST['ItmInv'];

$sql = "SELECT itemId, itemName, itemAmount, `itemBarcode`, Category.categoryName, Status.statusName, itemDate FROM `Item` 
INNER JOIN Category ON Item.categoryId = Category.categoryId 
INNER JOIN Status ON Item.statusId = Status.statusId
WHERE Item.inventoryId = $itm_i AND Item.categoryId = $categoryId AND Item.IsArchive != 1";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) { 
    while ($row = mysqli_fetch_array($result)) {
        $index++;
        echo '<tr>';
        echo '<td class="align-middle">
                <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="' . $row['itemId'] . '" aria-label="...">
                </td>';
        echo '<th class="align-middle">' . $index . '</th>';
        echo '<td class="align-middle">' . $row['itemName'] . '</td>';
        echo '<td class="align-middle">' . $row['itemAmount'] . '</td>';
        echo '<td class="align-middle">' . $row['statusName'] . '</td>';
        echo '<td class="align-middle">' . $row['categoryName'] . '</td>';

        echo '<td class="align-middle">';
        echo '<a href="#"  data-bs-toggle="collapse" data-bs-target="#colps' . $row['itemId'] . '" aria-expanded="false" aria-controls="collapseExample">';
        echo '<img data-bs-toggle="tooltip" data-bs-title="show item history" src="../assets/caret-down-solid.svg" width="16px" alt="" class="">';
        echo '</a>';
        echo '</td>';

        echo '<td class="align-middle"><a href="#" data-bs-toggle="tooltip" data-bs-title="download barcode" onclick="downloadBarcodeImg(' . "'" . $row['itemName'] . "'" . ', ' . $row['itemBarcode'] . ')">';
        echo '<img src="../assets/download-solid.svg" width="16px" alt="" class="">';
        echo '</a></td>';
        echo '<td class="align-middle">' . $row['itemBarcode'] . '</td>';

        echo '<td class="text-end">';
        echo '<a href="#"  data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
        echo '<img data-bs-toggle="tooltip" data-bs-title="edit item" src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
        echo '</a>';
        echo '</td>';
        echo '</tr>';

        echo '
        <tr>
            <td colspan="10" class="collapse" id="colps' . $row['itemId'] . '">
                <div class="card card-body">
                    <table class="table table-hover">
                        <thead>
                            <th>Item</th>
                            <th>Inventory</th>
                            <th>Added</th>
                            <th>Modified</th>
                            <th></th>
                        </thead>
                        <tbody>';
                        $id = $row['itemId'];
                        $sql4 = "SELECT `historyId`, Item.itemName, Inventory.inventoryName, `dateAdded`, `dateModified`, `dateRemoved` FROM `ItemHistory` 
                        LEFT JOIN Item ON ItemHistory.itemId = Item.itemId 
                        LEFT JOIN Inventory ON ItemHistory.inventoryId = Inventory.inventoryId 
                        WHERE ItemHistory.itemId = $id";

                        $res2 = mysqli_query($conn, $sql4);

                        if (mysqli_num_rows($res2) > 0) {
                            while ($row = mysqli_fetch_array($res2)) {
                                echo '<tr>
                                        <td>'. $row['itemName'] .'</td>
                                        <td>'. $row['inventoryName'] .'</td>
                                        <td>'. $row['dateAdded'] .'</td>
                                        <td>'. $row['dateModified'] .'</td>
                                    </tr>';
                            }
                        }
                        echo '</tbody>
                    </table>
                </div>
            </td>
        </tr>';
    }
    // while ($row = mysqli_fetch_array($result)) {
    //     echo '<tr>';
    //     echo '<td class="align-middle">
    //             <input name="chkBoxDelItem" class="form-check-input" type="checkbox" id="checkboxDelItem" value="' . $row['itemId'] . '" aria-label="...">
    //         </td>';
    //     echo '<th class="align-middle">'; echo $row['itemId']; echo '</th>';
    //     echo '<td class="align-middle">'; echo $row['itemName']; echo '</td>';
    //     echo '<td class="align-middle">'; echo $row['statusName']; echo '</td>';
    //     echo '<td class="align-middle"><strong>'. $row['categoryName'] .'</strong></td>';
    //     echo '<td class="align-middle">'; echo $row['itemDate']; echo '</td>';
    //     echo '<td class="text-end">';
    //     echo '<a href="" data-bs-toggle="modal" data-bs-target="#editItemModal" onclick="openEditItem(' . $row['itemId'] . ')">';
    //     echo '<img src="../assets/pen-to-square-solid.svg" width="16px" alt="" class="">';
    //     echo '</a>';
    //     echo '</td>';
    //     echo '</tr>';
    // }
}else { 
    echo '<tr>';
    echo '<td colspan="6">';
    echo '  <h1 class="text-secondary p-3 text-center">No Items In this Category</h1>';
    echo '</td>';
    echo '</tr>'; 
}
