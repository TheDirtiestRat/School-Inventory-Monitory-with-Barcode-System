<?php
require "connect_db.php";
require 'session.php';

$u_id = $_SESSION['userId'];
$barcode = $_POST['barCode'];

if ($u_id == 1) {
    $sql = "SELECT Item.itemId, Item.itemName, Category.categoryName, Item.inventoryId, Status.statusName, Inventory.inventoryName FROM `Item` 
    LEFT JOIN Category ON Item.categoryId = Category.categoryId 
    LEFT JOIN Status ON Item.statusId = Status.statusId 
    LEFT JOIN Inventory ON Item.inventoryId = Inventory.inventoryId 
    WHERE itemBarcode = $barcode AND Item.inventoryId IN (SELECT inventoryId FROM Inventory) AND Item.isArchive = 0;";
}else {
    $sql = "SELECT Item.itemId, Item.itemName, Category.categoryName, Item.inventoryId, Status.statusName, Inventory.inventoryName FROM `Item` 
    LEFT JOIN Category ON Item.categoryId = Category.categoryId 
    LEFT JOIN Status ON Item.statusId = Status.statusId 
    LEFT JOIN Inventory ON Item.inventoryId = Inventory.inventoryId 
    WHERE itemBarcode = $barcode AND Item.inventoryId IN (SELECT inventoryId FROM Inventory WHERE userId = $u_id) AND Item.isArchive = 0;";
}


$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $itm_id = $row['itemId'];
        $itm_name = $row['itemName'];
        $itm_ivn = $row['inventoryId'];

        echo '<h1>Details</h1>
                <hr>';
        echo '<div class="h-100 overflow-scroll"><div class="row">
            <div class="col-4"><p class="lead">Item Name</p></div>
            <div class="col"><p class="lead"><strong>' . $row['itemName'] . '</strong></p></div>
        </div>
        <div class="row">
            <div class="col-4"><p class="lead">Inventory</p></div>
            <div class="col"><p class="lead">' . $row['inventoryName'] . '</p></div>
        </div>
        <div class="row">
            <div class="col-4"><p class="lead">Categrory</p></div>
            <div class="col"><p class="lead">' . $row['categoryName'] . '</p></div>
        </div>
        <div class="row">
            <div class="col-4"><p class="lead">Status</p></div>
            <div class="col"><p class="lead">' . $row['statusName'] . '</p></div>
        </div>
        <div class="row">
            <div class="col-4"><p class="lead">Current Transaction:</p></div>
            <div class="col">';

        $sql2 = "SELECT transactionName, itemId FROM `Transaction` WHERE itemId = $itm_id";
        $res = mysqli_query($conn, $sql2);

        $isBorrowed = false;
        $Brr_name;
        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_array($res)) {
                echo '<p class="lead">' . $row['transactionName'] . '</p>';
                $Brr_name = $row['transactionName'];
            }
            $isBorrowed = true;
        } else {
            echo '<p class="lead">None</p>';
            $isBorrowed = false;
        }

        if ($u_id == 1) {
            echo '</div>
            </div>
            <button type="button" class="btn btn-dark m-1 float-end" data-bs-toggle="modal" data-bs-target="#updateItemModal" onclick="openUpdateItemModal('. $itm_id .','. $itm_ivn .','. "'". $itm_name . "'". ','. json_encode($isBorrowed) .','. "'". $Brr_name ."'" .')">
                Update item
            </button>';
        }
        echo '<button type="button" class="btn btn-secondary m-1 float-end" onclick="closeItemInfoDetails()">
            close
        </button></div>';
    }
} else {
    echo '<div class=" h-100 w-100">
    <h1 class="text-secondary">The code is invalid, try again</h1>
    <button type="button" class="btn btn-dark m-1" onclick="closeItemInfoDetails()">
            close
        </button>
    </div>';
}
