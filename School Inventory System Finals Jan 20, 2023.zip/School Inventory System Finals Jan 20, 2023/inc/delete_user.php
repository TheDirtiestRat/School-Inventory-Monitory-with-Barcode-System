<?php
require "connect_db.php";
require 'session.php';

$delBtn = $_POST['deleteConfirm'];

$sql = "DELETE FROM `User` WHERE `userId` = $delBtn;";

if (mysqli_query($conn, $sql)) {
    echo "User Deleted successfully";

    header("Location: add_newUser.php?alert=User Deleted successfully");
} else {
    echo "Deleting User failed";

    header("Location: add_newUser.php?error=Deleting User failed, the user is either being used");
}
