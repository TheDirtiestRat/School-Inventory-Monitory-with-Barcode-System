<?php
require "connect_db.php";
require 'session.php';

$inv_n = $_POST['InvName'];
// $inv_n = $_POST['inputInvName'];

if ($inv_n == "") {
    // header("Location: fileMaintenance.php?alert=Inventory name input is empty");
    echo '<div class="alert alert-danger" role="alert">
        Inventory name is empty
        </div>';
    return;
}

$u_id = $_SESSION['userId'];

$sql = "INSERT INTO `Inventory` (`inventoryId`, `inventoryName`, `userId`) VALUES (NULL, '$inv_n', '$u_id');";

if (mysqli_query($conn, $sql)) {
    // header("Location: fileMaintenance.php?alert=Inventory Added successfully");
    echo '<div class="alert alert-success" role="alert">
            New Inventory is Added successfully
        </div>';
} else {
    // header("Location: fileMaintenance.php?error=Adding Inventory failed");
    echo '<div class="alert alert-danger" role="alert">
            Failed to Add new Inventory, Invalid Input!
        </div>';
}

?>