<?php
require "connect_db.php";
require 'session.php';

$brr_n = $_POST['BrrName'];
$itm_id = $_POST['ItmId'];

$u_id = $_SESSION['userId'];

$sql = "SELECT `transactionComplete` FROM `Transaction` WHERE `itemId` = $itm_id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// checks if you have inputed a borrower name
if ($brr_n == "") {
    echo '<div class="alert alert-danger alert-dismissible" role="alert">
            <div>You havent inputed a Borrower name</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    return;
}
// Checks if the items is being currently borrowed
if ($row['transactionComplete'] == 1) {
    echo '<div class="alert alert-danger alert-dismissible" role="alert">
            <div>Item is still being Borrowed</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    return;
}

$sql = "INSERT INTO `Transaction` (`transactionId`, `transactionName`, `itemId`, `transactionDate`, `userId`, `transactionComplete`) VALUES (NULL, '$brr_n', '$itm_id', CURRENT_DATE(), '$u_id', '1');";

if ($result = mysqli_query($conn, $sql)) {
    $sql = "SELECT `transactionId`, `itemId` FROM `Transaction` WHERE `transactionId` = (SELECT LAST_INSERT_ID())";
    $result = mysqli_query($conn, $sql);

    $row = mysqli_fetch_assoc($result);

    $t_n = $row['transactionId'];
    $t_i = $row['itemId'];

    $sql = "INSERT INTO `Archive`(`archiveId`, `itemName`, `currentHolder`, `dateUpdated`) VALUES (NULL,'$t_i','$t_n', CURRENT_DATE());";
    mysqli_query($conn, $sql);

    // if (mysqli_num_rows($result) > 0) {

    // }
    // $sql = "INSERT INTO `Archive`(`archiveId`, `itemName`, `currentHolder`, `dateUpdated`) VALUES (NULL,'1','1', CURRENT_DATE());";
    // mysqli_query($conn, $sql);

    echo '<div class="alert alert-success alert-dismissible" role="alert">
            <div>New Transaction added</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
} else {

    echo '<div class="alert alert-danger alert-dismissible" role="alert">
            <div>Failed to process Transaction</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';

    // $sql = "SELECT `transactionComplete` FROM `Transaction` WHERE `itemId` = $itm_id";
    // $result = mysqli_query($conn, $sql);


    // if (strpos(mysqli_error($conn), "for key")) {
    //     echo '<div class="alert alert-danger alert-dismissible" role="alert">
    //         <div>Item is still being Borrowed</div>
    //         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    //     </div>';
    // }
    // else {
    //     echo '<div class="alert alert-danger alert-dismissible" role="alert">
    //         <div>Failed to process Transaction</div>
    //         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    //     </div>';
    // }
}
