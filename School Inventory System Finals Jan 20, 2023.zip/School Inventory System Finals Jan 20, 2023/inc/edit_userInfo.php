<?php
require "connect_db.php";
require 'session.php';

$u_fname = $_POST['Fname'];
$u_lname = $_POST['Lname'];
$u_uname = $_POST['Uname'];

$u_email = $_POST['Email'];
$u_pass = $_POST['Newpass'];
$u_cont = $_POST['Contact'];
$u_occu = $_POST['userOccupation'];
$u_addr = $_POST['Address'];

if (
    $u_uname == "" || $u_fname == "" || $u_lname == ""
    || $u_email == "" || $u_pass == "" || $u_cont == "" || $u_addr == ""
) {
    echo '<div class="alert alert-danger" role="alert">
        Failed to upadate info!
        </div>';
    return;
}

$u_id = $_SESSION['userId'];
$sql = "UPDATE `User` SET `userName`='$u_uname',`userPass`='$u_pass',`userFirstName`='$u_fname',`userLastName`='$u_lname',`userEmail`='$u_email',`userContact`='$u_cont',`userAddress`='$u_addr', `userOccupation` = '$u_occu' WHERE userId = $u_id;";

if (mysqli_query($conn, $sql)) {
    echo 'User info updated';

    header("Location: profile.php?alert=Profile details updated");
} else {
    echo 'Failed to upadate details!';
    header("Location: profile.php?error=Failed to upadate details! ". $u_uname. "/".$u_fname. "/".$u_lname. "/".$u_email. "/".$u_pass. "/".$u_cont. "/".$u_occu. "/".$u_addr);
}
