<?php
require "connect_db.php";
require 'session.php';

$id = $_SESSION['userId'];

if (isset($_POST['submit'])) {
    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTemp = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = strtolower(end(explode('.', $fileName)));

    $allowed = array('jpg', 'png', 'jpeg');

    $fileNewName = "profile" . $id . "." . $fileExt;
    $folderDes = '../files/uploads/' . $fileNewName;

    if (in_array($fileExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 1000000) {

                if (move_uploaded_file($fileTemp, $folderDes)) {
                    echo "file successfully uploaded ";

                    $sql = "UPDATE `User` SET `userPictureFile` = '$fileNewName' WHERE `User`.`userId` = $_SESSION[userId];";
                    $result = mysqli_query($conn, $sql);

                    header("Location: profile.php?alert=Profile Picture Updated");
                } else {
                    echo "file upload failed ";

                    header("Location: profile.php?error=File Upload Failed");
                }
            } else {
                echo 'File is too big';

                header("Location: profile.php?error=File is too big");
            }
        } else {
            echo 'Error uploading file';

            header("Location: profile.php?error=Error uploading file");
        }
    } else {
        echo 'File type is invalid';

        header("Location: profile.php?error=File type is invalid");
    }
}
