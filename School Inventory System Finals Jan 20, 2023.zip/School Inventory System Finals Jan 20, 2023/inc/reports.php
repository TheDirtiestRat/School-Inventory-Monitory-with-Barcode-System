<?php

require "connect_db.php";
require_once 'session.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/xlsx.full.min.js"></script>
</head>

<body>

    <!--Nav Bar-->
    <?php include "navbar.php"; ?>


    <!-- Content section -->
    <section class="nb-padding">
        <div class="p-4 pb-0" id="headerStats">
            <div class="bg-white">
                <div class="row">
                    <div class="col d-flex align-items-end">
                        <h1 class=" display-3 m-0">Inventory Reports</h1>
                    </div>
                    <div class="col d-flex align-items-end justify-content-end">
                        <p class="lead m-0">
                            <?php echo date("l jS \of F Y"); ?>
                        </p>
                    </div>
                </div>
            </div>
            <hr>
        </div>

        <div class="container-fluid p-4 pt-0 ">

            <div class="row mb-4">
                <div class="col">
                    <div class=" h-100">
                        <div class="row pb-4 h-50">
                            <div class="col">
                                <div class="card h-100">
                                    <div class="card-body text-center ">
                                        <h5 class="card-title">Inventory</h5>
                                        <?php
                                        $u_id = $_SESSION['userId'];

                                        if ($u_id == 1) {
                                            $sql = "SELECT COUNT(inventoryId) as total_inv FROM `Inventory`;";
                                        } else {
                                            $sql = "SELECT COUNT(inventoryId) as total_inv FROM `Inventory` WHERE userId = $u_id;";
                                        }

                                        $result = mysqli_query($conn, $sql);

                                        $row = mysqli_fetch_assoc($result);
                                        ?>
                                        <h1 class="m-0 display-4"><?php echo $row['total_inv']; ?></h1>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <?php
                                        if ($u_id == 1) {
                                            $sql = "SELECT COUNT(Item.itemId) as total_items FROM `Inventory` 
                                            LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId";
                                        } else {
                                            $sql = "SELECT COUNT(Item.itemId) as total_items FROM `Inventory` 
                                            LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId 
                                            WHERE userId = $u_id";
                                        }

                                        $result = mysqli_query($conn, $sql);

                                        $row = mysqli_fetch_assoc($result);
                                        ?>
                                        <h5 class="card-title">Items</h5>
                                        <h1 class="m-0 display-4"><?php echo $row['total_items']; ?></h1>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row h-50">
                            <div class="col">
                                <div class="card h-100 text-center">
                                    <div class="card-header">
                                        total Transaction
                                    </div>
                                    <?php
                                    if ($u_id == 1) {
                                        $sql = "SELECT COUNT(*) FROM `Transaction` GROUP BY itemId";
                                    } else {
                                        $sql = "SELECT COUNT(*) FROM `Transaction` WHERE userId = $u_id GROUP BY itemId";
                                    }

                                    $result = mysqli_query($conn, $sql);

                                    $row = mysqli_num_rows($result);
                                    $brr_items = $row;
                                    ?>
                                    <div class="card-body">
                                        <h1 class="m-0 display-4"><?php echo $row; ?></h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100">
                        <div class="card-header">
                            Inventory
                            <a href="#" class=" float-end" data-bs-toggle="tooltip" data-bs-title="download table" onclick="downloadTable('inventory-table-itemsTotal', 'xlsx', 'Inventory')">
                                <img src="../assets/download-solid.svg" width="16px" alt="" class="">
                            </a>
                        </div>
                        <div class="card-body">
                            <div class=" overflow-scroll" style="height: 350px;">
                                <table class="table" id="inventory-table-itemsTotal">
                                    <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Items Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($u_id == 1) {
                                            $sql = "SELECT inventoryName, COUNT(Item.inventoryId) as total FROM `Inventory` LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId GROUP BY inventoryName;";
                                        } else {
                                            $sql = "SELECT inventoryName, COUNT(Item.inventoryId) as total FROM `Inventory` LEFT JOIN Item ON Inventory.inventoryId = Item.inventoryId WHERE userId = $u_id GROUP BY inventoryName;";
                                        }

                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)) {
                                                echo '<tr>';
                                                echo "<td>";
                                                echo $row['inventoryName'];
                                                echo "</td>";
                                                echo "<td>";
                                                echo $row['total'];
                                                echo "</td>";
                                                echo '</tr>';
                                            }
                                        } else {
                                            echo '<h3 class=" text-secondary">No Inventories added yet</h3>';
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col">
                    <div class="card h-100">
                        <div class="card-header">
                            Item Status
                            <a href="#" class=" float-end" data-bs-toggle="tooltip" data-bs-title="download table" onclick="downloadTable('status-table-itemsTotal', 'xlsx', 'Status')">
                                <img src="../assets/download-solid.svg" width="16px" alt="" class="">
                            </a>
                        </div>
                        <div class="card-body h-100">
                            <div class=" overflow-scroll" style="height: 350px;">
                                <table class="table" id="status-table-itemsTotal">
                                    <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Items Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($u_id == 1) {
                                            $sql = "SELECT statusName, COUNT(Item.categoryId) AS total_stat, Inventory.inventoryId, Inventory.userId FROM STATUS LEFT JOIN Item ON STATUS.statusId = Item.statusId LEFT JOIN Inventory ON STATUS.inventoryId = Inventory.inventoryId GROUP BY statusName;";
                                        } else {
                                            $sql = "SELECT statusName, COUNT(Item.categoryId) AS total_stat, Inventory.inventoryId, Inventory.userId FROM STATUS LEFT JOIN Item ON STATUS.statusId = Item.statusId LEFT JOIN Inventory ON STATUS.inventoryId = Inventory.inventoryId WHERE Inventory.userId = $u_id GROUP BY statusName;";
                                        }

                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)) {
                                                echo '<tr>';
                                                echo "<td>";
                                                echo $row['statusName'];
                                                echo "</td>";
                                                echo "<td>";
                                                echo $row['total_stat'];
                                                echo "</td>";
                                                echo '</tr>';
                                            }
                                        } else {
                                            echo '<h3 class=" text-secondary">No Status added yet</h3>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col">
                    <div class="card h-100">
                        <div class="card-header">
                            Item Category
                            <a href="#" class=" float-end" data-bs-toggle="tooltip" data-bs-title="download table" onclick="downloadTable('category-table-itemsTotal', 'xlsx', 'Category')">
                                <img src="../assets/download-solid.svg" width="16px" alt="" class="">
                            </a>
                        </div>
                        <div class="card-body">
                            <div class=" overflow-scroll" style="height: 350px;">
                                <table class="table" id="category-table-itemsTotal">
                                    <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Items Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($u_id == 1) {
                                            $sql = "SELECT categoryName, COUNT(Item.categoryId) AS total_cat, Inventory.inventoryId, Inventory.userId FROM Category LEFT JOIN Item ON Category.categoryId = Item.categoryId LEFT JOIN Inventory ON Category.inventoryId = Inventory.inventoryId GROUP BY categoryName;";
                                        } else {
                                            $sql = "SELECT categoryName, COUNT(Item.categoryId) AS total_cat, Inventory.inventoryId, Inventory.userId FROM Category LEFT JOIN Item ON Category.categoryId = Item.categoryId LEFT JOIN Inventory ON Category.inventoryId = Inventory.inventoryId WHERE Inventory.userId = $u_id GROUP BY categoryName;";
                                        }

                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)) {
                                                echo '<tr>';
                                                echo "<td>";
                                                echo $row['categoryName'];
                                                echo "</td>";
                                                echo "<td>";
                                                echo $row['total_cat'];
                                                echo "</td>";
                                                echo '</tr>';
                                            }
                                        } else {
                                            echo '<h3 class=" text-secondary">No Categories added yet</h3>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                    <div class="card h-100">
                        <div class="card-header">
                            Transaction History Log
                            <a href="#" class=" float-end" data-bs-toggle="tooltip" data-bs-title="download table" onclick="downloadTable('archiveHistory-table-itemsTotal', 'xlsx', 'ArchiveHistory')">
                                <img src="../assets/download-solid.svg" width="16px" alt="" class="">
                            </a>
                        </div>
                        <div class="card-body">
                            <div class=" overflow-scroll" style="height: 350px;">
                                <table class="table" id="archiveHistory-table-itemsTotal">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Item Name</th>
                                            <th scope="col">Current Transaction</th>
                                            <th scope="col">Archive Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT `archiveId`, Item.itemName, Transaction.transactionName, `dateUpdated` FROM `Archive`
                                                INNER JOIN Item ON Archive.itemName = Item.itemId
                                                INNER JOIN Transaction ON Archive.currentHolder = Transaction.transactionId ORDER BY archiveId DESC;";
                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)) {
                                                $index++;
                                                echo '<tr>';
                                                echo '<td>' . $index . '</td>';
                                                echo '<td>' . $row['itemName'] . '</td>';
                                                echo '<td>' . $row['transactionName'] . '</td>';
                                                echo '<td>' . $row['dateUpdated'] . '</td>';
                                                echo '</tr>';
                                            }
                                        } else {
                                            echo '<h3 class=" text-secondary">No Transaction History</h3>';
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                    <div class="card h-100">
                        <div class="card-header">
                            Item History Log
                            <a href="#" class=" float-end" data-bs-toggle="tooltip" data-bs-title="download table" onclick="downloadTable('itemHistory-table-itemsTotal', 'xlsx', 'itemHistory')">
                                <img src="../assets/download-solid.svg" width="16px" alt="" class="">
                            </a>
                        </div>
                        <div class="card-body">
                            <div class=" overflow-scroll" style="height: 350px;">
                                <table class="table" id="itemHistory-table-itemsTotal">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Item</th>
                                            <th scope="col">Inventory</th>
                                            <th scope="col">Date Added</th>
                                            <th scope="col">Date Removed</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // $sql = "SELECT `itemId`, `itemName`, `itemAmount`, Inventory.inventoryName, `itemDate` FROM `Item`
                                        // LEFT JOIN Inventory ON Item.inventoryId = Inventory.inventoryId ORDER BY itemId DESC;";
                                        $sql = "SELECT `historyId`, Item.itemName, Inventory.inventoryName, `dateAdded`, `dateModified`, `dateRemoved` FROM `ItemHistory` 
                                        LEFT JOIN Item ON ItemHistory.itemId = Item.itemId 
                                        LEFT JOIN Inventory ON ItemHistory.inventoryId = Inventory.inventoryId;";

                                        $result = mysqli_query($conn, $sql);

                                        if (mysqli_num_rows($result) > 0) {
                                            $index = 0;
                                            while ($row = mysqli_fetch_array($result)) {
                                                $index++;
                                                echo '<tr>';
                                                echo '<td>' . $index . '</td>';
                                                echo '<td>' . $row['itemName'] . '</td>';
                                                echo '<td>' . $row['inventoryName'] . '</td>';
                                                echo '<td>' . $row['dateAdded'] . '</td>';
                                                echo '<td>' . $row['dateRemoved'] . '</td>';
                                                echo '</tr>';
                                            }
                                        } else {
                                            echo '<h3 class=" text-secondary">No Item history</h3>';
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>

    <!-- Script functionality -->
    <script>
        // for initializing the bootstrap tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

        // for downloading the table into an exel form
        function downloadTable(t_id_n, exp_type, tb_name, fn, dl) {
            var elt = document.getElementById(t_id_n);
            var wb = XLSX.utils.table_to_book(elt, {
                sheet: tb_name + " sheet"
            });
            return dl ?
                XLSX.write(wb, {
                    bookType: exp_type,
                    bookSST: true,
                    type: 'base64'
                }) :
                XLSX.writeFile(wb, fn || (tb_name + 'SheetTable.' + (exp_type || 'xlsx')));
        }
    </script>
</body>

</html>