<?php
require "connect_db.php";
require 'session.php';

$itm_id = $_POST['itemID'];
$itm_n = $_POST['newItmName'];
$itm_c = $_POST['newItmCat'];
$itm_s = $_POST['newItmStat'];

if ($itm_n == "") {
    echo '<div class="alert alert-danger" role="alert">
        New name is empty
        </div>';
    return;
}

$sql = "UPDATE `Item` SET `itemName` = '$itm_n', `categoryId` = '$itm_c', `statusId` = '$itm_s', `itemDate` = CURRENT_DATE() WHERE `Item`.`itemId` = $itm_id;
        UPDATE `ItemHistory` SET `dateModified`= CURRENT_DATE WHERE `itemId` = $itm_id";

if (mysqli_multi_query($conn, $sql)) {
    echo '<div class="alert alert-success" role="alert">
            Item '.$itm_n.' Edited 
        </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Edit Item!
        </div>';
}

?>