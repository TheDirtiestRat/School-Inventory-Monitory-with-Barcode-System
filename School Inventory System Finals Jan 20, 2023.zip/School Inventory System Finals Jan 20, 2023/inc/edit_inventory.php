<?php
require "connect_db.php";
require 'session.php';

$new_inv_name = $_POST['newInvName'];
$inv_id = $_POST['Inv_id'];

if ($new_inv_name == "") {
    echo '<div class="alert alert-danger" role="alert">
        New Inventory name is empty
        </div>';
    return;
}

$sql = "UPDATE `Inventory` SET `inventoryName` = '$new_inv_name' WHERE `Inventory`.`inventoryId` = $inv_id";

if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-success" role="alert">
            Sucessfully Edited
            </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Edit Inventory!
        </div>';
}

?>