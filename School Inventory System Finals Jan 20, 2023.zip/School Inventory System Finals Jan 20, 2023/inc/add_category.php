<?php
require "connect_db.php";
require 'session.php';

$cat_n = $_POST['CatName'];
$cat_i = $_POST['CatInv'];

if ($cat_n == "") {
    echo '<div class="alert alert-danger" role="alert">
        Category name is empty
        </div>';
    return;
}

$sql = "INSERT INTO `Category` (`categoryId`, `categoryName`, `inventoryId`) VALUES (NULL, '$cat_n', '$cat_i ');";

if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-success" role="alert">
            New Category is Added successfully
        </div>';
} else {
    echo '<div class="alert alert-danger" role="alert">
            Failed to Add new Category, Invalid Input!
        </div>';
}

?>