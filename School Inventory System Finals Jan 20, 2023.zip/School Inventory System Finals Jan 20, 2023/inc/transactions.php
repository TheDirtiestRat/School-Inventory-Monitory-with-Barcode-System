<?php

require "connect_db.php";
require_once 'session.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions</title>

    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <!--Navigation bar-->
    <?php include "navbar.php"; ?>

    <!--Information section-->
    <section class="nb-padding">
        <div class="p-4 pb-1" id="headerStats">
            <div class="row ">
                <div class="col-8 d-flex align-items-end">
                    <h1 class="display-3 mb-0">Transactions of today</h1>
                    <p class="lead m-0"><?php echo date("d / m / Y"); ?></p>
                </div>

                <div class="col d-flex text-center justify-content-end" id="itmBrrNumbers">

                </div>
            </div>

            <hr>
        </div>


        <div class="row m-0 ps-4 pe-4">
            <div class="col-sm mb-3 mb-sm-0 overflow-scroll">
                <!-- Items details -->
                <div class=" visually-hidden p-3" id="itemDetailsElement">

                </div>

                <!--Table-->
                <div class="" id="transactionListElement">
                    <div class="w-100 text-center pb-2">
                        <button type="button" class="btn btn-dark btn-lg" data-bs-toggle="modal" data-bs-target="#scanModal">
                            New Transaction
                        </button>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">Borrower</th>
                                <th scope="col">Item name</th>
                                <th scope="col">Date</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider" id="transTable">

                        </tbody>
                    </table>
                </div>
            </div>

            <!-- The barcode scanner -->
            <div class="col-sm ">
                <div class="border border-radius p-3 w-100" style="height: auto">
                    <div class=" h-75 w-100">
                        <div class="visually-hidden" id="scnItmInfo">
                        </div>

                        <!-- <div> -->
                        <div class="h-100 w-auto d-flex align-items-center justify-content-center" id="scnInterface">
                            <div class="d-none h-100 w-100" id="reader"></div>

                            <div class="text-center" id="scanItemshere">
                                <div class=" container-fluid" style="height: 400px;">
                                    <h1 class="">Scan Items here</h1>
                                    <button type="button" class="btn btn-dark btn-sm" onclick="openScanner ()">
                                        Open Scanner
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="">
                        <hr>
                        <label class="form-label"><strong>Barcode</strong></label>
                        <input type="number" class="form-control" id="inputBarcode" placeholder="Input Barcode" autofocus>
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!--Modals-->
    <div class="modal fade" id="scanModal" tabindex="-1" aria-labelledby="scanModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="scanModal">
                        New Transaction
                    </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <form action="" id="inputbc">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Borrower name</label>
                            <input type="text" class="form-control" id="brrName" placeholder="Name of the Borrower">
                        </div>

                        <?php
                        $u_id = $_SESSION['userId'];

                        if ($u_id == 1) {
                            $sql = "SELECT inventoryId, inventoryName FROM `Inventory`";
                        } else {
                            $sql = "SELECT inventoryId, inventoryName FROM `Inventory` WHERE userId = $u_id;";
                        }

                        $result = mysqli_query($conn, $sql);
                        ?>

                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">
                                From Inventory</label>
                            <select class="form-select" aria-label="Defaultselectexample" id="invIdValue">
                                <?php

                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_array($result)) {
                                        $id = $row['inventoryId'];

                                        echo "<option value=" . $id . ">" . $row['inventoryName'] . "</option>";
                                    }
                                } else {
                                    echo '<option value="1">No Inventory</option>';
                                }

                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Item to borrow</label>

                            <div class="overflow-scroll border border-radius" style="max-height: 200px;">
                                <ul class="list-group" id="ItmList">
                                    <li class="list-group-item text-secondary">
                                        No Items
                                    </li>
                                </ul>
                            </div>
                            </select>
                        </div>
                    </form>

                    <div id="transAlert">

                    </div>

                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" onclick="addNewTransaction()">
                        Add new Transaction
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- update Item modal -->
    <div class="modal fade" id="updateItemModal" tabindex="-1" aria-labelledby="updateItem" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-dark">
                    <h1 class="modal-title fs-5 text-light" id="updateItem">
                        Update Item
                    </h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h3>Item Status</h3>

                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Item name</label>
                        <h5 id="itemNameDisplay">Name of the Item</h5>
                    </div>

                    <form action="" id="editItemForm">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Current Status</label>
                            <select class="form-select" aria-label="Defaultselectexample" name="selectCat" id="slctUptStat">

                            </select>
                        </div>
                    </form>

                    <div id="transactionInfo" class=" visually-hidden">
                        <hr>

                        <h3>Transaction Status</h3>

                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Borrower</label>
                            <h5 id="borrowerNameDisplay">Name of the Borrower</h5>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="isItemReturned" value="">
                            <label class="form-check-label" for="defaultCheck1">
                                Is item been returned?
                            </label>
                        </div>
                    </div>

                    <div id="updateItmWrnAlrt">

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark" onclick="UpdateItem()">
                        Update Item
                    </button>
                </div>
            </div>
        </div>
    </div>


    <!--Scripts-->
    <script src="../js/custom js/responseOutputscript.js"></script>
    <script src="../node_modules/html5-qrcode/html5-qrcode.min.js"></script>
    <script>
        var myModal = document.getElementById('scanModal');
        var myInput = document.getElementById('inputBarcode');

        var slctInv = document.querySelector('#invIdValue');
        var item_ID = 0;

        var barcodeInput = document.getElementById('inputBarcode');

        //initialize them on load
        getItmList(document.getElementById("invIdValue").value);
        getTransactionList();
        getTotalBorrowedItems();

        //selects the current inventory item list
        slctInv.addEventListener("change", function() {
            getItmList(document.getElementById("invIdValue").value);
        });

        myModal.addEventListener('shown.bs.modal', function() {
            myInput.focus()
        })

        //check the barcode
        barcodeInput.addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                // alert(barcodeInput.value);
                // getItemDetails(barcodeInput.value);
                // console.log(barcodeInput.value);
                openItemInfoDetails(barcodeInput.value);
                barcodeInput.value = "";
            }
        });

        //gets the scanned items information
        function getItemDetails(barcode) {
            var parameters = {
                "barCode": barcode,
            };

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    const scniteminfo = document.getElementById("itemDetailsElement");
                    scniteminfo.innerHTML = this.responseText;
                }

            };

            console.log(barcode);

            xmlhttp.open("POST", "get_itemDetails.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send(createParameterString(parameters));
        }

        //to add the new transaction
        function addNewTransaction() {
            var parameters = {
                "BrrName": document.getElementById('brrName').value,
                "ItmId": item_ID
            };

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("transAlert").innerHTML = this.responseText;
                    getTransactionList();
                    getTotalBorrowedItems();
                }

            };

            console.log(document.getElementById('brrName').value, item_ID);

            xmlhttp.open("POST", "add_transaction.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send(createParameterString(parameters));
        }


        //get the list of the transaction in this day
        function getTransactionList() {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("transTable").innerHTML = this.responseText;
                    closeItemInfoDetails();
                }

            };

            xmlhttp.open("POST", "get_transactionList.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send();
        }

        //gets the borrowed items
        function getTotalBorrowedItems() {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("itmBrrNumbers").innerHTML = this.responseText;
                }

            };

            xmlhttp.open("POST", "get_transactionNumbers.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send();
        }

        function getItemId(evt, itm_id) {
            item_ID = itm_id;
            console.log(itm_id)

            // Get all elements with class="tablinks" and remove the class "active"
            var item = document.getElementsByClassName("list-group-item");
            for (i = 0; i < item.length; i++) {
                item[i].className = item[i].className.replace(" active", "");
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            evt.currentTarget.className += " active";
        }

        //for generating the items based from the inventory
        function getItmList(inv_id) {
            var parameters = {
                "ItmInv": inv_id,
            };

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("ItmList").innerHTML = this.responseText;
                }

            };

            xmlhttp.open("POST", "get_selectItmList.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send(createParameterString(parameters));
        }

        var itemId = 0;

        // when the update item button is opened
        function openUpdateItemModal(itm_id, inv_id, itm_name, isborrowed, brr_name) {
            itemId = itm_id;
            document.getElementById("itemNameDisplay").innerText = itm_name;
            requestResponseOutputAjax("slctUptStat", "getInventoryStatus.php", inv_id);

            var transInfo = document.getElementById("transactionInfo");
            var brrNmDis = document.getElementById("borrowerNameDisplay");
            if (isborrowed) {
                transInfo.className += "visually-hidden";
                if (brr_name == "") {
                    brrNmDis.innerText = "none"
                } else {
                    brrNmDis.innerText = brr_name;
                }

            } else {
                transInfo.className.replace("visually-hidden", "");

            }
        }

        // updates the current item
        function UpdateItem() {
            var checkbox = document.querySelector('#isItemReturned')
            var ischecked = 0;
            if (checkbox.checked == true) {
                ischecked = 1
            } else {
                ischecked = 0
            }

            var parameters = {
                "ItmId": itemId,
                "CurItmStat": document.getElementById("slctUptStat").value,
                "IsBrr": ischecked
            };

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("updateItmWrnAlrt").innerHTML = this.responseText;
                    getTransactionList();
                    getTotalBorrowedItems();
                }

            };

            xmlhttp.open("POST", "update_itemTransaction.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send(createParameterString(parameters));
        }

        // opens the Items details interface
        function openItemInfoDetails(barcode) {
            const itmDetailsElement = document.getElementById("itemDetailsElement");
            const tranTableElement = document.getElementById("transactionListElement");

            itmDetailsElement.className = itmDetailsElement.className.replace("visually-hidden", " ");
            tranTableElement.classList.add("visually-hidden");

            getItemDetails(barcode);
        }

        function closeItemInfoDetails() {
            const itmDetailsElement = document.getElementById("itemDetailsElement");
            const tranTableElement = document.getElementById("transactionListElement");

            tranTableElement.className = tranTableElement.className.replace("visually-hidden", " ");
            itmDetailsElement.classList.add("visually-hidden");
        }

        // barcode scanner for the device camera
        function openScanner() {
            const scanner = document.getElementById("reader");
            const startscreen = document.getElementById("scanItemshere");

            scanner.className = scanner.className.replace("d-none", " ");

            // if (!startscreen.classList.contains("visually-hidden")) {
            //     startscreen.classList.add("visually-hidden");
            // }
            if (!startscreen.classList.contains("d-none")) {
                startscreen.classList.add("d-none");
            }

            html5QrcodeScanner.render(onScanSuccess, onScanError);
        }

        function onScanSuccess(qrCodeMessage) {
            // document.getElementById('result').innerHTML = '<span class="result">' + qrCodeMessage + '</span>';
            openItemInfoDetails(qrCodeMessage);
            console.log(`Scan result: ${qrCodeMessage}`);

            // html5QrcodeScanner.clear();
        }

        function onScanError(errorMessage) {
            // console.warn(`Code scan error = ${errorMessage}`);
        }


        var html5QrcodeScanner = new Html5QrcodeScanner(
            "reader", {
                fps: 2,
                qrbox: 250,
                aspectRatio: 1.0,
                formatsToSupport: [Html5QrcodeSupportedFormats.UPC_A]
            },
            false);


        document.getElementById("updateItemModal").addEventListener('hidden.bs.modal', function() {
            document.getElementById("updateItmWrnAlrt").innerHTML = "";

        })
    </script>
</body>

</html>