function requestResponseOutputAjax(ele_id, src_php, inv_id) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById(ele_id).innerHTML = this.responseText;
        }
    };

    xmlhttp.open("GET", src_php + "?q=" + inv_id, true);
    xmlhttp.send();
}

function createParameterString(parameters) {
    // Create parameter string
    var parameterString = "";
    var isFirst = true;
    for (var index in parameters) {
        if (!isFirst) {
            parameterString += "&";
        }
        parameterString += encodeURIComponent(index) + "=" + encodeURIComponent(parameters[index]);
        isFirst = false;
    }

    return parameterString;
}