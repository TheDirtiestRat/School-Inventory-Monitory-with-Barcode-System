function searchItem() {
    var inv_id = inventoryId;
    var srchInput = document.getElementById('searchBar').value;

    var params = {
        "search": srchInput,
        "inv": inventoryId
    };
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("item_table" + inv_id).innerHTML = this.responseText;
        }

    };

    xmlhttp.open("POST", "search_items.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(params));
}

document.getElementById('slcSort').onchange = function () {
    var slcSortingBy = document.getElementById('slcSort');

    var inv_id = inventoryId;

    var parameters = {
        "ItmOrder": slcSortingBy.value,
        "ItmInv": inv_id
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("item_table" + inv_id).innerHTML = this.responseText;
        }

    };


    xmlhttp.open("POST", "sort_items.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}