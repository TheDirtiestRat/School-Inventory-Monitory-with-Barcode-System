// other functions and methods?
function getInventoryList () {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("inventoryList").innerHTML = this.responseText;
        }
    };

    xmlhttp.open ("POST", "get_inventoryList.php", true);
    xmlhttp.send();
    

}
function getInvStatList (){
    requestResponseOutputAjax("InvStatList", "get_InvStatuslist.php", inventoryId);
}
function getInvCatList (){
    requestResponseOutputAjax("InvCatList", "get_InvCategorylist.php", inventoryId);
}

// Items modal script
function addItem() {
    var inv_id = inventoryId;

    var parameters = {
        "ItmName": document.getElementById("inputItmName").value,
        "itemSpecify": document.getElementById("inputItmSpecify").value,
        "ItmInv": document.getElementById("selectInv").value,
        "ItmCat": document.getElementById("selectCat").value,
        "ItmStat": document.getElementById("selectStat").value,
        "ItmAmount": document.getElementById("inputAmount").value
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            document.getElementById("inputItmName").reset();
            document.getElementById("selectInv").reset();
            document.getElementById("selectCat").reset();
            document.getElementById("selectStat").reset();
            document.getElementById("inputAmount").reset();
        }

    };

    xmlhttp.open("POST", "add_item.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}

function openAddItemModal() {
    requestResponseOutputAjax("selectCat", "getInventoryCategory.php", inventoryId);
    requestResponseOutputAjax("selectStat", "getInventoryStatus.php", inventoryId);
}

function deleteItems() {
    var inv_id = inventoryId;
    var arr = document.querySelectorAll('input[type="checkbox"]:checked');
    var parameters = "";

    for (var i = 0; i < arr.length; i++) {
        parameters += "items[]=" + arr[i].value + "&";
    }
    //Remove the last char which is '&'
    parameters = parameters.substring(0, parameters.length - 1);

    console.log(parameters);

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            requestResponseOutputAjax("item_table" + inv_id, "getInventoryItems.php", inv_id);

        }

    };

    xmlhttp.open("POST", "delete_items.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(parameters);
}

function selectItemsToDelete() {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    var notif = document.getElementById('dltNotif');
    var yesDelBtn = document.getElementById('yesDel');

    if (checkboxes.length > 1) {
        notif.innerHTML = "Are you sure you want to remove " + checkboxes.length + " items?";
    } else if (checkboxes.length == 1) {
        notif.innerHTML = "Are you sure you want to remove this item?";
    } else {
        notif.innerHTML = "No items are selected"
    }
}

function openEditItem(itm_id) {
    item_id = itm_id;
    requestResponseOutputAjax("slctEditCat", "getInventoryCategory.php", inventoryId);
    requestResponseOutputAjax("slctEditStat", "getInventoryStatus.php", inventoryId);
}

function editItm() {
    var inv_id = inventoryId;
    var itm_id = item_id;

    var parameters = {
        "itemID": itm_id,
        "newItmName": document.getElementById("newItemNameInput").value,
        "newItmCat": document.getElementById("slctEditCat").value,
        "newItmStat": document.getElementById("slctEditStat").value,
        "ItmInv": inv_id
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            requestResponseOutputAjax("item_table" + inv_id, "getInventoryItems.php", inv_id);
        }

    };

    xmlhttp.open("POST", "edit_item.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}

document.getElementById("editItemModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("editItemForm").reset();
    document.getElementById("editWrnAlrt").innerHTML = "";
})

document.getElementById("addItemModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("addItmForm").reset();
    document.getElementById("itemWrnAlrt").innerHTML = "";
})

// Category modal script
function addCat() {
    var inv_id = inventoryId;

    var parameters = {
        "CatName": document.getElementById("inputCatName").value,
        "CatInv": inv_id
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;

        }

    };

    xmlhttp.open("POST", "add_category.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));


}
function delCat(cat_id) {
    var inv_id = inventoryId;
    var parameters = {
        "CatId": cat_id
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            getInvCatList();
        }

    };

    xmlhttp.open("POST", "delete_category.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}

document.getElementById("addCategoryModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("catForm").reset();
    document.getElementById("categoryWrnAlrt").innerHTML = "";
})


// Status modal script
function addStat() {
    var inv_id = inventoryId;

    var parameters = {
        "StatName": document.getElementById("inputStatName").value,
        "StatInv": inv_id
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;

        }

    };

    xmlhttp.open("POST", "add_status.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}

document.getElementById("addStatusModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("addStatForm").reset();
    document.getElementById("statusWrnAlert").innerHTML = "";
})
function delStat(stat_id) {
    var inv_id = inventoryId;
    var parameters = {
        "StatId": stat_id
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            getInvStatList();
        }

    };

    xmlhttp.open("POST", "delete_status.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}


// Inventory modal script
function addInv() {

    // var inv_id = inventoryId;
    var parameters = {
        "InvName": document.getElementById("inputInvName").value
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            getInventoryList();
            window.location = "../inc/fileMaintenance.php";
        }

    };

    xmlhttp.open("POST", "add_inventory.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}

function deleteInventory() {
    var inv_id = inventoryId;

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            getInventoryList();
        }
    };


    xmlhttp.open("POST", "delete_inventory.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send("InvId=" + inv_id);
}

function onDelInv(inv_name) {
    console.log(inv_name);
    var notif = document.getElementById('dltInvNotif');

    notif.innerHTML = "Are you sure you want to delete <strong> " + inv_name + "</strong> Inventory?";
}

document.getElementById("deleteInventoryModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("invAlrtDel").innerHTML = "";
});

document.getElementById("addInventoryModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("addInvForm").reset();
    document.getElementById("invWrnAlrt").innerHTML = "";
})


function editInventory() {
    var parameters = {
        "newInvName": document.getElementById("newInvNameInput").value,
        "Inv_id": inventoryId
    };

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("liveAlertPlaceholder").innerHTML = this.responseText;
            getInventoryList();
            console.log("this is a test")
        }

    };

    xmlhttp.open("POST", "edit_inventory.php", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(createParameterString(parameters));
}

function getCatAndStatList(inv_name) {
    document.getElementById('prevInvName').value = inv_name;

    requestResponseOutputAjax("InvCatList", "get_InvCategorylist.php", inventoryId);
    requestResponseOutputAjax("InvStatList", "get_InvStatuslist.php", inventoryId);
}

document.getElementById("editInventoryModal").addEventListener('hidden.bs.modal', function () {
    document.getElementById("newInvNameInput").value = "";
    document.getElementById("editWrnAlrt").innerHTML = "";
});
